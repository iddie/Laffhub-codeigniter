<?php
namespace Aws\Exception;

class CredentialsException extends \RuntimeException {}
