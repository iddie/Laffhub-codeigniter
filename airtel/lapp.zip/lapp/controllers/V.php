<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Africa/Lagos');

class V extends CI_Controller {	
	
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->model('getdata_model');
		
	 }

	public function AddComment()
	{		#category, filename, videocode, name, comment
		$email=''; $category=''; $filename=''; $videocode=''; $name=''; $comment=''; $videotitle='';
		$phone='';
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = trim($this->input->post('email'));
		if ($this->input->post('category')) $category = trim($this->input->post('category'));
		if ($this->input->post('filename')) $filename = trim($this->input->post('filename'));
		if ($this->input->post('videotitle')) $videotitle = trim($this->input->post('videotitle'));
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('name')) $name = $this->input->post('name');
		if ($this->input->post('comment')) $comment = $this->input->post('comment');		
#$file = fopen('aaa.txt',"w"); fwrite($file,$action); fclose($file);
				
		//Check if record exists
		$sql = "SELECT * FROM comments WHERE ((TRIM(phone)='".$this->db->escape_str($phone)."') OR (TRIM(email)='".$this->db->escape_str($email)."')) AND (TRIM(videocode)='".$this->db->escape_str($videocode)."') AND (TRIM(comment)='".$this->db->escape_str($comment)."')";
		$query = $this->db->query($sql);
					
		if ($query->num_rows() > 0 )
		{
			$ret = 'Comment <b>'.strtoupper($comment).'</b> for the video <b>'.strtoupper($videotitle).'</b> has already been added.';
		}else
		{
			$dt=date('Y-m-d H:i:s');
			
			$this->db->trans_start();
									
			$dat=array(
				'email' => $this->db->escape_str($email),
				'phone' => $this->db->escape_str($phone),
				'category' => $this->db->escape_str($category),
				'filename' => $this->db->escape_str($filename),
				'videotitle' => $this->db->escape_str($videotitle),
				'videocode' => $this->db->escape_str($videocode),
				'name' => $this->db->escape_str($name),
				'comment' => $this->db->escape_str($comment),				
				'commentstatus' => 1,
				'commentdate' => $dt
				);							
			
			$this->db->insert('comments', $dat);
			
			$this->db->trans_complete();
			
			$Msg='';
			
			if ($this->db->trans_status() === FALSE)
			{
				if ($phone)
				{
					$Msg="Subscriber ".strtoupper($name.'('.$phone.')')." attempted adding comment but failed.";
				}elseif ($email)
				{
					$Msg="Subscriber ".strtoupper($name.'('.$email.')')." attempted adding comment but failed.";
				}
								
				$ret = 'Comment Addition Was Not Successful.';
			}else
			{
				if ($phone)
				{
					$Msg="Comment By Subscriber ".strtoupper($name.'('.$phone.')')." Was Added Successfully.";
				}elseif ($email)
				{
					$Msg="Comment By Subscriber ".strtoupper($name.'('.$email.')')." Was Added Successfully.";
				}				
								
				$ret = 'OK'	;
			}
			
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
			$this->getdata_model->LogDetails($name,$Msg,$email,date('Y-m-d H:i:s'),$remote_ip,$remote_host,'ADDED COMMENT',$_SESSION['LogID']);
		}
		
		echo $ret;
	}
	
	public function PlayVideo()
	{
		$videocode=''; $subscriptionId=''; $MaxVideo=''; $VideoTitle=''; $thumbnail=''; 
		$VideosWatched=0; $SubscriberEmail=''; $DurationInSeconds='0'; $Plan=''; $CurrentVideoCount=0;
		$SubscriberName=''; $phone=''; $network=''; $CommentsCount='0'; $videolist=''; $CanPlayVideo=false;
		$NoPlayReason=''; $CanPlayNew=false; $lang=''; $useragent='';
		
		$phone=$this->getdata_model->GetMSISDN();
		$network=$this->getdata_model->GetNetwork();
		
		$data['Phone']=$phone;
		$data['Network']=$network;
		$ret=$network;
		
		$this->getdata_model->CheckSubscriptionDate('',$data['Phone']);
				
		#Check network
		if (strtolower(trim($ret))=='airtel')
		{
			$rt=$this->getdata_model->CheckForBlackList($data['Network'],$data['Phone']);
			
			if ($rt==true)#Blacklisted
			{
				$this->load->view('blist',$data);	
			}else
			{
				if ($this->uri->segment(1)) $videocode=trim(str_replace('c-','',$this->uri->segment(1)));
		
				$tdt=date("Y-m-d H:i:s");
				
				$data['filename']=''; $data['title']=''; $data['jwplayer_key']='';
				$data['description']=''; $data['category']=''; $data['domain_name']='';
				$data['distribution_Id']=''; $data['origin'] = '';
				$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
				$data['SubscribeStatus'] = '0';	
				
				$useragent=$_SERVER['HTTP_USER_AGENT'];
				$lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
				
				$this->getdata_model->LoadRegularSession($data['Phone']);
				
				#Get Player Key
				if ($_SESSION['jwplayer_key']) $data['jwplayer_key'] = $_SESSION['jwplayer_key'];
				if ($_SESSION['thumbs_bucket']) $ThumbBucket = $_SESSION['thumbs_bucket'];
				
				#Get domain_name
				if ($_SESSION['distribution_Id']) $data['distribution_Id']=$_SESSION['distribution_Id'];
				if ($_SESSION['domain_name']) $data['domain_name'] = $_SESSION['domain_name'];
				if ($_SESSION['origin']) $data['origin'] = $_SESSION['origin'];
				
				#Check if subscriber has record in subscription table
				#subscriptionId,videos_cnt_to_watch,subscriptionstatus
				$sql = "SELECT * FROM subscriptions WHERE (TRIM(msisdn)='".$this->db->escape_str($phone)."') ";
				
				$query = $this->db->query($sql);
				
				if ($query->num_rows() > 0 )
				{
					$row = $query->row();
					
					if ($row->subscriptionId) $subscriptionId=trim($row->subscriptionId);
					if ($row->videos_cnt_to_watch) $MaxVideo=trim($row->videos_cnt_to_watch);
					if ($row->subscriptionstatus) $subscription_status=$row->subscriptionstatus;
					if ($row->plan) $Plan=trim($row->plan);
					if ($row->email) $SubscriberEmail=trim($row->email);
					
					if (strtolower($MaxVideo)=='unlimited') $MaxVideo='1000000000';
					
					$data['subscriber_email']= $SubscriberEmail;
					$data['MaxVideo']=$MaxVideo;
					$data['subscriptionId'] = $subscriptionId;
					
					if (!$subscription_status) $subscription_status='0';
					
					#Check if Subscription is active
					$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$phone);
									
					if (is_array($result))
					{
						foreach($result as $rw)
						{
							if ($rw->subscribe_date) $dt = date('F d, Y',strtotime($rw->subscribe_date));
							
							$data['subscribe_date'] = $dt;
							
							if ($rw->exp_date) $edt = date('F d, Y',strtotime($rw->exp_date));
							$data['exp_date'] = $edt;
							
							if ($tdt > date('Y-m-d H:i:s',strtotime($rw->exp_date)))
							{
								if ($rw->subscriptionstatus==1)
								{
									#Update Subscription Date
									$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$phone,'0');
									$data['SubscribeStatus'] = '0';
								}
							}else
							{
								if (!$rw->subscriptionstatus)
								{
									$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$phone,'1');
									$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
									$data['SubscribeStatus'] = '1';
								}else
								{
									$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
									$data['SubscribeStatus'] = '1';
								}
							}
		
							break;
						}
					}	
	
					if (intval($data['SubscribeStatus'],10) == 1)
					{
						#Get Video Lists
						$sql = "SELECT videolist FROM watchlists WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
			
						$query = $this->db->query($sql);
						
						#Get VideosWatched
						if ($query->num_rows() > 0 )
						{
							$row = $query->row();
						
							if ($row->videolist) $videolist=trim($row->videolist);
							
							if ($videolist <> '') $VideosWatched=count(explode('^',$videolist)); else $VideosWatched=0;
						}else
						{
							$VideosWatched=0;
						}
						
						$data['VideosWatched']=$VideosWatched;
						$SpareView=false;
						
						#Get Current Video Count
						if ($videolist <> '')
						{
							$arrWatched=array(); 
					
							$arrTotalWatched=explode('^',$videolist);
							
							if (count($arrTotalWatched)>0)
							{
								foreach($arrTotalWatched as $itm):
									if ($itm)
									{
										$ex=explode('|',$itm);
										
										if (count($ex)>0)
										{
											if (trim($ex[0])== trim($videocode)) $CurrentVideoCount=$ex[1];
											if (intval($ex[1],10) < 3) $SpareView=true;
										}
									}
								endforeach;
							}
						}
						
						$data['CurrentVideoCount']=$CurrentVideoCount;
						
						#Get Video Duration & Total Comments
						$sql = "SELECT * FROM videos WHERE (play_status=1) AND (encoded=1) AND (TRIM(video_code)='".$this->db->escape_str($videocode)."')";
			
						$query = $this->db->query($sql);
									
						if ($query->num_rows() > 0 )
						{
							$row = $query->row();
						
							if ($row->filename) $data['filename']=$row->filename;
							if ($row->video_title) $data['title']=$row->video_title;
							if ($row->description) $data['description']=$row->description;
							if ($row->category) $data['category']=$row->category;
							if ($row->thumbnail) $data['thumbnail']=$row->thumbnail;
	
							if ($row->duration)
							{
								$data['duration']=$row->duration;				
								$d=explode(':',$row->duration);
								
								$sec=0;
								
								if (count($d)==3)
								{
									$sec=(intval($d[0],10)*120)+(intval($d[1],10)*60)+intval($d[2],10);
								}elseif (count($d)==2)
								{
									$sec=(intval($d[0],10)*60)+intval($d[1],10);
								}
								
								$data['duration_secs']=$sec;
							}
							
							#Comments 
							$data['Comments']=$this->getdata_model->GetVideoComments($data['category'],$videocode,$data['filename']);
							if (count($data['Comments'])>1)
							{
								$data['CommentsCount']=count($data['Comments']).' Comments';
							}else
							{
								$data['CommentsCount']=count($data['Comments']).' Comment';
							}
						}
						
						$data['NewVideoPlay']='-1';
						$RePlayOld=false;
							
						###PUTTING ALL TOGETHER
						#Check if current video maximum count of 3 has been reached
						if ($CurrentVideoCount >= 3)
						{
							if (intval($VideosWatched,10) >= intval($MaxVideo,10))
							{
								if ($SpareView==true)#Can watch other videos
								{
									#Stop but can choose another video
									$CanPlayVideo=false;
									$NoPlayReason='You can only watch <b>'.$MaxVideo.'</b> videos for the current subscription plan. Please note that each selected video can be watched 3 times. Any video you have not watched up to 3 times can be rewatched.';
									$CanPlayNew=false;
									$RePlayOld=true;
								}else#Exhausted
								{
									#Stop. Exhausted all videos
									$CanPlayVideo=false;
									$NoPlayReason='You have exhausted all the videos you are allowed to watch for the current subscription plan. Please renew your subscription.';
									$CanPlayNew=false;
									$RePlayOld=false;
								}							
							}else#$VideosWatched < $MaxVideo
							{
								#Stop but can choose another video
								if ($SpareView==true)
								{
									$CanPlayVideo=false;
									$CanPlayNew=true;
									$RePlayOld=true;
									$NoPlayReason='You have reached The maximum number of times the selected video can be watched. You can, however, watch a new video or any other video that you have watched less than 3 times.';
								}else
								{
									$CanPlayVideo=false;
									$CanPlayNew=true;
									$RePlayOld=false;
									$NoPlayReason='You have reached The maximum number of times the selected video can be watched. You can, however, watch a new video.';
								}							
							}
						}else#$CurrentVideoCount < 3
						{
							#Check if it is a new video
							if ($videolist <> '')
							{
								$arrWatched=array(); $newvideo=true;
						
								$arrTotalWatched=explode('^',$videolist);
								
								if (count($arrTotalWatched)>0)
								{
									foreach($arrTotalWatched as $itm):
										if ($itm)
										{
											$ex=explode('|',$itm);
											
											if (count($ex)>0)
											{
												if (trim($ex[0])== trim($videocode))
												{
													$newvideo=false;
													break;
												}
											}
										}
									endforeach;
								}
							}
							
							if ($newvideo==true)
							{
								if (intval($VideosWatched,10) < intval($MaxVideo,10))#Play
								{
									#Play
									$CanPlayVideo=true;
									$CanPlayNew=true;
									$NoPlayReason='';
									$RePlayOld=true;
									$SpareView=true;
									$data['NewVideoPlay']=true;	
								}else#Maxvideo reached - Stop
								{
									if ($SpareView==true)#Can only watched old not up to 3
									{
										#Stop but can replay old movie
										$RePlayOld=true;
										$CanPlayVideo=false;
										$NoPlayReason='You can only watch <b>'.trim($MaxVideo).'</b> videos for the current subscription plan. Please note that each video can be watched 3 times. You can rewatch any video you have not watched up to 3 times.';
										$CanPlayNew=false;
										$data['NewVideoPlay']=false;
									}else
									{
										#Stop. Exhausted all videos
										$CanPlayVideo=false;
										$RePlayOld=false;
										$NoPlayReason='You have exhausted all the videos you are allowed to watch for the current subscription plan. Please renew your subscription.';
										$CanPlayNew=false;	
									}
								}	
							}else#Old video
							{
								#Play
								$CanPlayVideo=true;
								$CanPlayNew=true;
								$NoPlayReason='';
								$RePlayOld=true;
								$data['NewVideoPlay']=true;
							}						
						}
						
						$data['CanPlayVideo']=$CanPlayVideo;
						$data['CanPlayNew']=$CanPlayNew;
						$data['NoPlayReason']=$NoPlayReason;
						$data['SpareView']=$SpareView;
						$data['newvideo']=$newvideo;
						$data['videolist']=$videolist;
						
						#Save Transaction
						$remote_ip=$_SERVER['REMOTE_ADDR'];
						$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
						
						#$tddate=date('Y-m-d H:i',strtotime($tdt));
						$tddate=date('Y-m-d',strtotime($tdt));
						
						#Check if it is first time it registering
						#$sql = "SELECT trans_date FROM transactions WHERE (DATE_FORMAT(trans_date,'%Y-%m-%d')='".$tddate."') AND (TRIM(video_code)='".$videocode."') AND (TRIM(phone)='".$phone."')";
					
						#$qry = $this->db->query($sql);
						
						$this->db->trans_start();
									
						$dat=array(
							'email' => $this->db->escape_str($data['subscriber_email']),
							'phone' => $this->db->escape_str($phone),
							'trans_date' => $tdt,
							'filename' => $this->db->escape_str($data['filename']),
							'video_code' => $this->db->escape_str($videocode),
							'user_agent' => $this->db->escape_str($useragent),
							'video_category' => $this->db->escape_str($data['category']),
							'remote_address' => $this->db->escape_str($remote_ip),	
							'remote_host' => $this->db->escape_str($remote_host),	
							'lang' => $this->db->escape_str($lang),
							'network' => $network
						);
						
						$this->db->insert('transactions', $dat);	
							
						$this->db->trans_complete();
						
						if ($this->db->trans_status() === FALSE)
						{
							$Msg="Transaction From Subscriber With Phone Number'".strtoupper($phone)." Failed.";	
							
							$this->getdata_model->LogDetails($phone,$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW WATCH VIDEO REQUEST','System');
						}else
						{
							$Msg="Transaction From Subscriber With Phone Number'".strtoupper($phone)." Was Successful.";	
							
							$this->getdata_model->LogDetails($phone,$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW WATCH VIDEO REQUEST','System');
						}
						
						$arr = explode('.', basename($data['filename']));
						$ext=array_pop($arr);				
						$fn=str_replace('.'.$ext,'',basename($data['filename']));
						
						$preview_img='https://s3-us-west-2.amazonaws.com/'.$ThumbBucket.'/'.$data['category'].'/'.$data['thumbnail'];
						$data['videocode'] = $videocode;
						$data['thumbs_bucket'] = $ThumbBucket;
						$data['preview_img']=$preview_img;
						$data['RelatedVideos']=$this->getdata_model->GetRelatedVideos($data['category'],$videocode);					
						$data['ViewPagePopularVideos']=$this->getdata_model->GetViewPagePopularVideos($videocode);
						$data['Categories']=$this->getdata_model->GetCategories();
	
	#$file = fopen('aaa.txt',"w"); fwrite($file,"Phone=".$phone."\nMaxVideo=".$MaxVideo."\nSubscribeStatus=".$data['SubscribeStatus']."\nVideo Code=".$videocode."\nCurrentVideoCount=".$CurrentVideoCount."\nVideosWatched=".$VideosWatched."\nCanPlayVideo=".$data['CanPlayVideo']."\nCanPlayNew=".$data['CanPlayNew']."\nNoPlayReason=".$data['NoPlayReason']."\nSubcriber Id=".$data['subscriptionId']."\nCategory=".$data['category']); fclose($file);
						
						$this->load->view('v_view',$data);
					}else
					{
						$this->load->view('expiredsubscription',$data);
					}
				}else
				{
					$this->load->view('nosubscription',$data);
				}	
			}
		}elseif (strtolower(trim($ret))=='mtn')
		{
			if ($host=='localhost')
			{
				redirect('http://localhost/laffhub/Home', 'refresh');
				#redirect('http://localhost/mtnlaffhub/Subscriberhome', 'refresh');
			}else
			{
				redirect('http://laffhub.com/Home', 'refresh');
				#redirect('http://mtn.laffhub.com/Subscriberhome', 'refresh');
			}
		}elseif (strtolower(trim($ret))=='wifi')
		{
			if ($host=='localhost')
			{
				redirect('http://localhost/laffhub/Home', 'refresh');
			}else
			{
				redirect('http://laffhub.com/Home', 'refresh');
			}				
		}else
		{
			if ($host=='localhost')
			{
				redirect('http://localhost/laffhub/Home', 'refresh');
			}else
			{
				redirect('http://laffhub.com/Home', 'refresh');
			}
		}
	}
	
	public function PlayVideo1()
	{
		$videocode=''; $subscriptionId=''; $videos_cnt_to_watch=''; $VideoTitle=''; $thumbnail='';
		$VideosWatched=0; $subscription_status='';
		
		if ($this->uri->segment(1)) $videocode=trim(str_replace('c-','',$this->uri->segment(1)));
				
		$tdt=date("Y-m-d H:i:s");
		
		$data['filename']=''; $data['title']=''; $data['jwplayer_key']='';
		$data['description']=''; $data['category']=''; $data['domain_name']='';
		$useragent=$_SERVER['HTTP_USER_AGENT'];
		$lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
		$phone=$this->getdata_model->GetMSISDN();
		$network=$this->getdata_model->GetNetwork();
		
		$this->getdata_model->LoadSubscriberSession($data['Phone']);
		
		#Get Player Key
		$sql="SELECT * FROM settings";
			
		$query = $this->db->query($sql);
				
		if ( $query->num_rows()> 0 )
		{
			$row = $query->row();	

			if ($row->jwplayer_key) $data['jwplayer_key'] = $row->jwplayer_key;
			if ($row->thumbs_bucket) $ThumbBucket = $row->thumbs_bucket;
		}
		
		#Get domain_name
		$sql="SELECT domain_name FROM streaming_domain";
			
		$query = $this->db->query($sql);
				
		if ( $query->num_rows()> 0 )
		{
			$row = $query->row();						
			if ($row->domain_name) $data['domain_name'] = $row->domain_name;
		}
		
		#Get Video record
		$sql = "SELECT * FROM videos WHERE (play_status=1) AND (encoded=1) AND (TRIM(video_code)='".$this->db->escape_str($videocode)."')";
		
		$query = $this->db->query($sql);
					
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
		
			if ($row->filename) $data['filename']=$row->filename;
			if ($row->video_title) $data['title']=$row->video_title;
			if ($row->description) $data['description']=$row->description;
			if ($row->category) $data['category']=$row->category;
			if ($row->thumbnail) $data['thumbnail']=$row->thumbnail;
						
			if ($row->duration)
			{
				$data['duration']=$row->duration;				
				$d=explode(':',$row->duration);
				
				$sec=0;
				
				if (count($d)==3)
				{
					$sec=(intval($d[0],10)*120)+(intval($d[1],10)*60)+intval($d[2],10);
				}elseif (count($d)==2)
				{
					$sec=(intval($d[0],10)*60)+intval($d[1],10);
				}
				
				$data['duration_secs']=$sec;
			}
			
			#Save Transaction
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
			
			$data['Phone']=$phone;
			$data['Network']=$network;
			$data['subscriber_email']=$_SESSION['subscriber_email'];	
			$data['subscriber_name'] = $_SESSION['subscriber_name'];
			$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
	
			$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$data['Phone']);
								
			if (is_array($result))
			{
				$td=date('Y-m-d H:i:s');
				
				foreach($result as $row)
				{
					if ($row->subscribe_date) $dt = date('F d, Y',strtotime($row->subscribe_date));
					
					$data['subscribe_date'] = $dt;
					
					if ($row->exp_date) $edt = date('F d, Y',strtotime($row->exp_date));
					$data['exp_date'] = $edt;
					
					if ($td > date('Y-m-d H:i:s',strtotime($row->exp_date)))
					{
						if ($row->subscriptionstatus==1)
						{
							#Update Subscription Date
							$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'0');
						}
					}else
					{
						if (!$row->subscriptionstatus)
						{
							$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'1');
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}else
						{
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}
					}

					break;
				}
			}
			
			#Get active subscription ID
			$sql = "SELECT subscriptionId,videos_cnt_to_watch,subscriptionstatus FROM subscriptions WHERE (TRIM(msisdn)='".$this->db->escape_str($phone)."') ";
			
			$query = $this->db->query($sql);
					
			if ($query->num_rows() > 0 )
			{
				$row = $query->row();
				
				if ($row->subscriptionId) $subscriptionId=trim($row->subscriptionId);
				if ($row->videos_cnt_to_watch) $videos_cnt_to_watch=$row->videos_cnt_to_watch;
				if ($row->subscriptionstatus) $subscription_status=$row->subscriptionstatus;
			}
			
			if (!$subscription_status) $subscription_status='0';
			
			#$tddate=date('Y-m-d H:i',strtotime($tdt));
			$tddate=date('Y-m-d',strtotime($tdt));
			
			#Check if it is first time it registering
			$sql = "SELECT trans_date FROM transactions WHERE (DATE_FORMAT(trans_date,'%Y-%m-%d')='".$tddate."') AND (TRIM(filename)='".$row->filename."') AND ((TRIM(remote_address)='".$_SERVER['REMOTE_ADDR']."') OR (TRIM(phone)='".$phone."'))";
		
			$qry = $this->db->query($sql);
						
			$dat=array(
				'email' => $this->db->escape_str($data['subscriber_email']),
				'phone' => $this->db->escape_str($phone),
				'trans_date' => $tdt,
				'filename' => $this->db->escape_str($row->filename),
				'video_code' => $this->db->escape_str($videocode),
				'user_agent' => $this->db->escape_str($useragent),
				'video_category' => $this->db->escape_str($row->category),
				'remote_address' => $this->db->escape_str($remote_ip),	
				'remote_host' => $this->db->escape_str($remote_host),	
				'lang' => $this->db->escape_str($lang),
				'network' => $network
			);
			
			$this->db->insert('transactions', $dat);	
				
			$this->db->trans_complete();
			
			if ($this->db->trans_status() === FALSE)
			{
				$Msg="Transaction From User Agent '".strtoupper($useragent).", Remote Host '".strtoupper($remote_host)."' AND Remote IP'".strtoupper($remote_ip)."' Failed.";	
				
				$this->getdata_model->LogDetails('System',$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW VIDEO REQUEST','System');
			}	
			
			$arr = explode('.', basename($row->filename));
			$ext=array_pop($arr);				
			$fn=str_replace('.'.$ext,'',basename($row->filename));
			
			$preview_img='https://s3-us-west-2.amazonaws.com/'.$ThumbBucket.'/'.$data['category'].'/'.$data['thumbnail'];
			
			$data['videocode'] = $videocode;
			$data['VideosToWatch'] = $videos_cnt_to_watch;
			$data['subscriber_phone'] = $phone;
			$data['video_category'] = $row->category;
			$data['thumbs_bucket'] = $ThumbBucket;
			$data['subscriptionId'] = $subscriptionId;
			
			$data['subscriber_status'] = $this->getdata_model->GetSubscriptionStatus($data['subscriber_email'],$phone);
			
			$data['subscription_status']=$subscription_status;
			$data['preview_img']=$preview_img;
			$data['RelatedVideos']=$this->getdata_model->GetRelatedVideos($row->category,$videocode);
			$data['Comments']=$this->getdata_model->GetVideoComments($row->category,$videocode,$row->filename);
			$data['ViewPagePopularVideos']=$this->getdata_model->GetViewPagePopularVideos($videocode);
			
			if (count($data['Comments'])>1)
			{
				$data['CommentsCount']=count($data['Comments']).' Comments';
			}else
			{
				$data['CommentsCount']=count($data['Comments']).' Comment';
			}
			
			$data['Categories']=$this->getdata_model->GetCategories();
			
			#Check if subscriber has exceeded no of videos allowed or max watch count for a video (3)
			#1. Get video list from watchlists
			$sql = "SELECT videolist FROM watchlists WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
		
			$query = $this->db->query($sql);
			
			$videolist='';
			
			if ($query->num_rows() > 0 )
			{
				$row = $query->row();
			
				if ($row->videolist) $videolist=trim($row->videolist);
			}
			
			#Check total number of videos watched - VideoCode|WatchCount^VideoCode|WatchCount
			if ($videolist <> '')
			{
				$arrWatched=array(); $tempTotal=0; $tempLimit=0; $codeexists=false;
				
				$arrTotalWatched=explode('^',$videolist);
				
				$VideosWatched=count($arrTotalWatched);
				
				$data['VideosWatched']=$VideosWatched;
				
				if (count($arrTotalWatched)>0)
				{
					$tempTotal=count($arrTotalWatched);
					
					foreach($arrTotalWatched as $itm):
						if ($itm)
						{
							$ex=explode('|',$itm);
							
							if (count($ex)>0)
							{
								$arrWatched[$ex[0]]=$ex[1]; #array[videocode]=watchcount
							}
						}
					endforeach;
				}
				
				if (count($arrWatched)>0)
				{					
					foreach($arrWatched as $code => $cnt): #foreach (array_expression as $key => $value)
						if ($code)
						{
							if (trim($code) == trim($videocode))
							{
								$codeexists=true;
								$tempLimit=intval($cnt,10);
								break;
							}
						}
					endforeach;
					
					#Code exists, check watch count
					if ($codeexists==true)
					{
						if ($tempLimit < 3)#OK
						{
							#Update WatchCount
							$data['ExceededTotal']='0';
							$data['ExceededVideoLimited']='0';
							$data['ExceededTotalVideos']='0';
							
							$this->load->view('v_view',$data);
						}else#Exceed video limit
						{
							$data['ExceededVideoLimited']='3';
							
							if (strtolower(trim($videos_cnt_to_watch)) <> 'unlimited')
							{
								if (intval($tempTotal,10) < intval($videos_cnt_to_watch,10))#OK
								{
									$data['ExceededTotal']='0';
									$data['ExceededTotalVideos']=intval($videos_cnt_to_watch,10)-intval($tempTotal,10);
								}else
								{
									$data['ExceededTotal']='1';
									$data['ExceededTotalVideos']=intval($videos_cnt_to_watch,10);
								}	
							}else
							{
								$data['ExceededTotal']='0';
								$data['ExceededTotalVideos']='Unlimited';
							}							
							
							$this->load->view('v_view',$data);
						}
					}else #Code not exist, check total videos
					{
						if (strtolower(trim($videos_cnt_to_watch)) <> 'unlimited')
						{
							if (intval($tempTotal,10) < intval($videos_cnt_to_watch,10))
							{
								$data['ExceededTotal']='0';
								$data['ExceededTotalVideos']=intval($videos_cnt_to_watch,10)-intval($tempTotal,10);
							}else
							{
								$data['ExceededTotal']='1';
								$data['ExceededTotalVideos']=intval($videos_cnt_to_watch,10);
							}
							
							$data['ExceededVideoLimited']='0';	
						}else
						{
							$data['ExceededTotal']='0';
							$data['ExceededTotalVideos']='Unlimited';
						}						
						
						$this->load->view('v_view',$data);
					}
				}else
				{
					#Update WatchCount
					$data['ExceededTotal']='0';
					$data['ExceededVideoLimited']='0';
					$data['ExceededTotalVideos']='0';
					
					$this->load->view('v_view',$data);	
				}
			}else
			{
				#Update WatchCount
				$data['ExceededTotal']='0';
				$data['ExceededVideoLimited']='0';
				$data['ExceededTotalVideos']='0';
				
				$this->load->view('v_view',$data);
			}
		}else
		{
			$this->load->view('notfound',$data);
		}
	}
	
	public function CheckForWatchCount()
	{
		$phone=''; $email=''; $videocode=''; $subscriptionId=''; $title='';
		$VideosWatched=0; $MaxVideo=0; $SpareView=false; $CurrentVideoCount=0;
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = $this->input->post('email');
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('subscriptionId')) $subscriptionId = trim($this->input->post('subscriptionId'));
		if ($this->input->post('title')) $title = trim($this->input->post('title'));
		
		#Get videos_cnt_to_watch
		$sql = "SELECT videos_cnt_to_watch FROM subscriptions WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
			
		$query = $this->db->query($sql);
				
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
			
			if ($row->videos_cnt_to_watch) $MaxVideo=trim($row->videos_cnt_to_watch);

			if (strtolower($MaxVideo)=='unlimited') $MaxVideo='1000000000';
		}
		
		#Get Video Lists
		$sql = "SELECT videolist FROM watchlists WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";

		$query = $this->db->query($sql);
		
		#Get VideosWatched
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
		
			if ($row->videolist) $videolist=trim($row->videolist);
			
			if ($videolist <> '') $VideosWatched=count(explode('^',$videolist)); else $VideosWatched=0;
		}else
		{
			$VideosWatched=0;
		}
		
		#Get Current Video Count
		if ($videolist <> '')
		{
			$arrWatched=array(); 
	
			$arrTotalWatched=explode('^',$videolist);
			
			if (count($arrTotalWatched)>0)
			{
				foreach($arrTotalWatched as $itm):
					if ($itm)
					{
						$ex=explode('|',$itm);
						
						if (count($ex)>0)
						{
							if (trim($ex[0])== trim($videocode)) $CurrentVideoCount=$ex[1];
							if (intval($ex[1],10) < 3) $SpareView=true;
						}
					}
				endforeach;
			}
		}
				
		#Check if current video maximum count of 3 has been reached
		if ($CurrentVideoCount >= 3)
		{
			if (intval($VideosWatched,10) >= intval($MaxVideo,10))
			{
				if ($SpareView==true)#Can watch other videos
				{
					#Stop but can choose another video
					$CanPlayVideo=false;
					$CanPlayNew=false;
					$RePlayOld=true;
					
					$data='You have reached the maximum number of times you can watch <b>'.strtoupper($title).'</b>. You can, however, watch a new video or any other video that you have watched less than 3 times.';
				}else#Exhausted
				{
					#Stop. Exhausted all videos
					$CanPlayVideo=false;
					$CanPlayNew=false;
					$RePlayOld=false;
					
					$data='You have reached the maximum number of videos and the maximum number of times you can watch each video for the current subscription plan.';
				}							
			}else#$VideosWatched < $MaxVideo
			{
				#Stop but can choose another video
				if ($SpareView==true)
				{
					$CanPlayVideo=false;
					$CanPlayNew=true;
					$RePlayOld=true;
					
					$data='You have reached the maximum number of times you can watch <b>'.strtoupper($title).'</b>. You can, however, watch a new video or any other video that you have watched less than 3 times.';
				}else
				{
					$CanPlayVideo=false;
					$CanPlayNew=true;
					$RePlayOld=false;
					
					$data='You have reached the maximum number of times you can watch <b>'.strtoupper($title).'</b>. You can, however, watch a new video.';
				}							
			}
		}else#$CurrentVideoCount < 3
		{
			$newvideo=false;
			#Check if it is a new video
			if ($videolist <> '')
			{
				$arrWatched=array(); $newvideo=true;
		
				$arrTotalWatched=explode('^',$videolist);
				
				if (count($arrTotalWatched)>0)
				{
					foreach($arrTotalWatched as $itm):
						if ($itm)
						{
							$ex=explode('|',$itm);
							
							if (count($ex)>0)
							{
								if (trim($ex[0])== trim($videocode))
								{
									$newvideo=false;
									break;
								}
							}
						}
					endforeach;
				}
			}
			
			if ($newvideo==true)
			{
				if (intval($VideosWatched,10) < intval($MaxVideo,10))#Play
				{
					#Play
					$CanPlayVideo=true;
					$CanPlayNew=true;
					$RePlayOld=true;
					
					$data='OK';
				}else#Maxvideo reached - Stop
				{
					if ($SpareView==true)#Can only watched old not up to 3
					{
						#Stop but can replay old movie
						$RePlayOld=true;
						$CanPlayVideo=false;
						$CanPlayNew=false;
						
						$data='You have reached the maximum number of times you can watch <b>'.strtoupper($title).'</b>. You can, however, watch any other video that you have watched less than 3 times.';
					}else
					{
						#Stop. Exhausted all videos
						$CanPlayVideo=false;
						$RePlayOld=false;
						$CanPlayNew=false;
						
						$data='You have reached the maximum number of videos and the maximum number of times you can watch each video for the current subscription plan.';
					}
				}	
			}else#Old video
			{
				#Play
				$CanPlayVideo=true;
				$CanPlayNew=true;
				$RePlayOld=true;
				
				$data='OK';
			}						
		}
		
		#$file = fopen('aaa.txt',"a"); fwrite($file,"\nMaxVideo=".$MaxVideo."\nVideosWatched=".$VideosWatched."\nData=".$data); fclose($file);
				
		echo $data;
	}
	
	public function UpdateWatchCount()
	{
		$phone=''; $email=''; $videocode=''; $subscriptionId='';	
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = $this->input->post('email');
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('subscriptionId')) $subscriptionId = trim($this->input->post('subscriptionId'));
		
		$this->getdata_model->SetWatchCount($videocode,$phone,$email,$subscriptionId);	
		
		echo 'OK';				
	}
	
#https://d2dm1rzdyku85l.cloudfront.net/Alzheimers_Risk_360p.mp4
#if ($domainname && $filename) $preview_url='https://'.$domainname.'/'.$filename;	
	public function index()
	{
				
	}
}
