<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <ul class="social">
          <li><a href="https://www.facebook.com/thelaffhub" class="facebook"><i class="fa fa-facebook-official"></i></a></li>
          <li><a href="https://www.instagram.com/laffhub/" class="instagram"><i class="fa fa-instagram"></i></a></li>
          <li><a href="#" class="youtube"><i class="fa fa-youtube-square"></i></a></li>
          <li><a href="https://twitter.com/laffhub" class="twitter"><i class="fa fa-twitter-square"></i></a></li>
          <li><a href="#" class="whatsapp"><i class="fa fa-whatsapp"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <ul class="social">
          <li><a href="#" >About us</a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#">App</a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#" >Cookie Policy </a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#" >FAQ</a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#">Terms of use</a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#" >Privacy Policy</a></li>
          <li><a href="#" >|</a></li>
          <li><a href="#" >Contact us</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>