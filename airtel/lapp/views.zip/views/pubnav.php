<div class="navbar-wrapper">
      <div class="container-fluid">
        <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a title="LaffHub Home" class="navbar-brand" href="<?php echo site_url("Home"); ?>"><img style="margin-top:-10px; margin-left:-10px;" src="<?php echo base_url();?>images/header_logo.png" /></a>
            </div>
            
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li title="LaffHub Home"><a href="<?php echo site_url("Home"); ?>"><span class="glyphicon glyphicon-home"></span> Home</a></li>
              </ul>
              
              <ul class="nav navbar-nav navbar-right">
              <li title="Publisher Login"><a id="mnuLogin" href="<?php echo site_url("Pubhome"); ?>"><span class="glyphicon glyphicon-log-in"></span> Publisher Login</a></li>
            </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>