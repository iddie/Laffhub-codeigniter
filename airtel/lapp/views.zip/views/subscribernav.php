<nav class="navbar navbar-default" role="navigation">
          <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-brand-centered">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button><div class="number">
      <span> <b> 08074117872 </b></span> </div>
          <div class="navbar-brand navbar-brand-centered"> <a class="navbar-brand" href="index.php"> <img src="images/logo.png" class="img-responsive"></a><div class="navbar-brand navbar-brand-censtered"> <a class="navbar-brand" href="index.php"> <img src="images/logo.png" class="img-responsive"></a></div></div></div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-brand-centered">
          <ul class="nav navbar-nav right">
          <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Categories <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">Categories1</a></li>
              <li><a href="#">Categories2</a></li>
              <li><a href="#">Categories3</a></li>
              <li><a href="#">Categories4</a></li>
            </ul>
          </li>
            <li><a href="comedian.php">Comedian <span class="sr-only">(current)</span></a></li>
          <li><a href="blog.php">Blog</a></li>
          <li><a href="events.php">Events</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li class="search-box">
            <form action="" autocomplete="on">
              <input id="search" name="search" type="text" placeholder="What're we looking for ?">
              <input id="search_submit" value="Rechercher" type="submit">
            </form>
          </li>
           <li class="dropdown dropdown2"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My Account <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="profile.php">Profile</a></li>
              <li><a href="index.php">Logout</a></li>
             
            </ul>
          </li>
        </ul>
      </div>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>