<footer class="main-footer">
        <div class="pull-right hidden-xs">
          
        </div>
        <strong>Copyright &copy; <?php echo date('Y');?> <a href="http://www.laffub.com" target="_blank">LaffHub</a>.</strong> All rights reserved.
      </footer>