
<script>
	var Title='<font color="#AF4442">LaffHub Help</font>';
	var m='';
	
	bootstrap_alert = function() {}
	bootstrap_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-danger alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#AF4442">'+message+'</font></span></div>')
	}
	
	bootstrap_Success_alert = function() {}
	bootstrap_Success_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-success alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#1B691A">'+message+'</font></span></div>')
	}
	
	$(document).ready(function(e) {
         //$(document).ajaxStop($.msg('unblock'));
		
		$('#btnSearch').click(function(e) {
            try
			{
				m='Click Search Button';
			   
				bootstrap_alert.warning(m);
			}catch(e)
			{
				self.unblock();
				var m='Search Button Click ERROR:\n'+e;
			   
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
				});
			}
        });
    });//End document ready
</script>


 
 <header class="page__header header ">
 	 	 <div class="container">
         	<div id="divAlert" align="center"></div>
         </div>
     
        <div class="container">
       
        
          <div class="header__left">
            <a href="<?php echo site_url('Subscriberhome'); ?>" class="logo js-ajax-link">
              <img src="<?php echo base_url(); ?>acss/images/logo.png" alt="">
            </a>
            <a href="<?php echo site_url('Subscriberhome'); ?>" class="logo js-ajax-link operator-logo">
              <img src="<?php echo base_url(); ?>acss/images/airtel_logo.png" alt="">
            </a>
            <nav class="header__nav">
              <ul class="header__nav-list">
                <li class="header__nav-item">
                  <a href="<?php echo site_url('Subscriberhome'); ?>" class="header__nav-link js-ajax-link"> Home</a>
                </li>
                <li class="header__nav-item header__nav-item--dropdown">
                  <a title="Video Categories" href="<?php echo site_url('Categories'); ?>" class="header__nav-link js-ajax-link mobile-ajax-off"> Categories </a>
                  <div class="header__nav-dropdown header__nav-dropdown--categories">
                   <?php
				   		if (count($Categories)>0)
						{
							$i=0;
							
							foreach($Categories as $row)
							{
								if ($row->category)
								{
									$i++;	
									
									if ($i==1) echo '<ul>';							
									
									echo '
										<li><a href="'.site_url('Categories/ShowCategories/'.$row->category).'" class="js-ajax-link">'.trim($row->category).'</a></li>
									';
									
									if ($i == 4)
									{
										 echo '</ul>';
										$i=0;
									}
								}
							}
						}
				   ?>
                   
                  </div>
                </li>
                <li class="header__nav-item">
                  <a href="<?php echo site_url('Comedianslist'); ?>" class="header__nav-link js-ajax-link"> Comedians </a>
                </li>
                
                <li class="header__nav-item">
                  <a href="<?php echo site_url('Subscribe'); ?>" class="header__nav-link js-ajax-link"> Subscribe </a>
                </li>
               
                <li class="header__nav-item">
                  <a class="header__nav-link js-ajax-link"> <span style="color:#CB5E3A; font-weight:bold;">Phone: <?php echo $Phone; ?> </span></a>
                </li>
              </ul>
            </nav>
          </div>
          
          
          <div class="header__right" style="margin-top:20px;">
            <div class="dropdown lng-dropdown">
              <a href="#" class="dropdown__toggle" data-toggle="dropdown">
                <span>My Account</span>
              </a>
              
              <ul class="dropdown-menu">
              	<li><a href="<?php echo site_url('Subscriberhome'); ?>"><span>Dashboard</span></a></li>
                <li><a href="<?php echo site_url('Profile'); ?>"><span>Profile</span></a></li>
                <li><a href="<?php echo site_url('Unsubscribe'); ?>"><span>Unsubscribe</span></a></li>
               
               	<li><a style="cursor:pointer;" onClick="if (confirm('Do you want to sign out? (Click OK to proceed or CANCEL to abort)')) window.location.href='<?php echo site_url('Subscriberlogout'); ?>';"><span>Sign Out</span></a></li>
              </ul>
              
            </div>
                        
            <a title="Search For Video" href="#" class="search-open"></a>
            <a title="Close Search Box"  href="#" class="search-close"></a>
          </div>
                    
          <!-- search form -->
          <form action="#" method="post" class="search" style="margin-top:20px;">
            <input type="text" name="search" class="search__field" placeholder="Search Laffhub" autocomplete="off">
            <button id="btnSearch" class="search__button" type="button"></button>
            <div class="search__enter"> Enter </div>
          </form>
          
          
          <!-- /search form -->
          <a href="#" class="menu-open">
            <span></span>
            <span></span>
            <span></span>
          </a>
          <a href="#" class="menu-close">
            <span></span>
            <span></span>
            <span></span>
          </a>
        </div>
        <div class="mobile-menu">
          <div class="mobile-menu__scroll-content"> </div>
        </div>
      </header>
      
    