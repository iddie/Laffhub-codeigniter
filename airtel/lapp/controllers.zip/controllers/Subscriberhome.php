<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscriberhome extends CI_Controller {	
	
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->model('getdata_model');
	 }
	 
	public function RateVideo()
	{
		$video_code=''; $email=''; $phone=''; $rating='';
		
		if ($this->input->post('video_code'))$video_code = trim($this->input->post('video_code'));
		if ($this->input->post('email'))$email = trim($this->input->post('email'));
		if ($this->input->post('phone'))$phone = trim($this->input->post('phone'));
		if ($this->input->post('rating'))$rating = trim($this->input->post('rating'));
		
		$rows='';
		
		#$file = fopen('aaa.txt',"w"); fwrite($file,"Video Code=".$video_code."\nEmail=".$email."\nPhone=".$phone."\nRating=".$rating); fclose($file);

		//Check if record exists
		if ($phone)
		{
			$phone=$this->getdata_model->CleanPhoneNo($phone);
			
			$sql = "SELECT * FROM user_ratings WHERE (TRIM(video_code)='".$this->db->escape_str($video_code)."') AND (TRIM(msisdn)='".$this->db->escape_str($phone)."')";
		}elseif ($email)
		{
			$sql = "SELECT * FROM user_ratings WHERE (TRIM(video_code)='".$this->db->escape_str($video_code)."') AND (TRIM(email)='".$this->db->escape_str($email)."')";
		}		
		
		$query = $this->db->query($sql);
		
		$VideoTitle=$this->getdata_model->GetVideoTitle($video_code);
				
		$subscriber_id=''; $Msg='';
#$file = fopen('aaa.txt',"w"); fwrite($file,$sql); fclose($file);			
		if ($phone)
		{
			$subscriber_id=$phone;
		}elseif ($email)
		{
			$subscriber_id=$email;
		}
		
		if ($query->num_rows() > 0 )#Update
		{
			$this->db->trans_start();
			
			if ($phone)
			{
				$dat=array(
					'video_code' => $this->db->escape_str($video_code),
					'msisdn' => $this->db->escape_str($phone),
					'email' => $this->db->escape_str($email),
					'rating' => $this->db->escape_str($rating)
					);							
				
				$this->db->where(array('video_code' => $this->db->escape_str($video_code),'msisdn' => $this->db->escape_str($phone)));
			}elseif ($email)
			{
				$dat=array(
					'video_code' => $this->db->escape_str($video_code),
					'email' => $this->db->escape_str($email),
					'msisdn' => $this->db->escape_str($phone),
					'rating' => $this->db->escape_str($rating)
					);							
				
				$this->db->where(array('video_code' => $this->db->escape_str($video_code),'email' => $this->db->escape_str($email)));
			}			
			
			$this->db->update('user_ratings', $dat);
			
			$this->db->trans_complete();
			
			if ($this->db->trans_status() === FALSE)
			{
				$Msg="Updating Of Rating Of The Video '".strtoupper($VideoTitle)." By Subscriber ".$subscriber_id." Failed.";
				
				$rows = "Rating Of Video Was Not Successful.";
			}else
			{
				$Msg="Updating Of Rating Of The Video '".strtoupper($VideoTitle)." By Subscriber ".$subscriber_id." Was Successful.";
				
				$rows='OK';
			}
			
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
			$this->getdata_model->LogDetails($subscriber_id,$Msg,$subscriber_id,date('Y-m-d H:i:s'),$remote_ip,$remote_host,'UPDATED VIDEO RATING',$_SESSION['LogID']);
		}else#Insert
		{				
			$this->db->trans_start();
			
			if ($phone)
			{
				$dat=array(
					'video_code' => $this->db->escape_str($video_code),
					'msisdn' => $this->db->escape_str($phone),
					'email' => $this->db->escape_str($email),
					'rating' => $this->db->escape_str($rating)
					);
			}elseif ($email)
			{
				$dat=array(
					'video_code' => $this->db->escape_str($video_code),
					'email' => $this->db->escape_str($email),
					'msisdn' => $this->db->escape_str($phone),
					'rating' => $this->db->escape_str($rating)
					);
			}														
			
			$this->db->insert('user_ratings', $dat);
			
			$this->db->trans_complete();
			
			$Msg='';
			
			if ($this->db->trans_status() === FALSE)
			{					
				$Msg="Rating Of The Movie '".strtoupper($MovieTitle)." By Subscriber ".$subscriber_id." Failed.";
				
				$rows = "Rating Of Video Was Not Successful.";
			}else
			{
				$Msg="Rating Of The Movie '".strtoupper($MovieTitle)." By Subscriber ".$subscriber_id." Was Successful.";
				
				$rows='OK';
			}
			
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
			$this->getdata_model->LogDetails($subscriber_id,$Msg,$subscriber_id,date('Y-m-d H:i:s'),$remote_ip,$remote_host,'RATED VIDEO',$_SESSION['LogID']);
		}
		
		echo $rows;
	}
	
	public function index()
	{
		$category='';
		
		if ($this->uri->segment(3)) $category=$this->uri->segment(3,'');
		
		$data['Network']=$this->getdata_model->GetNetwork();
		$data['Phone']=$this->getdata_model->GetMSISDN();
		
		$this->getdata_model->CheckSubscriptionDate('',$data['Phone']);
		
		$ret=$this->getdata_model->CheckForBlackList($data['Network'],$data['Phone']);
#$file = fopen('aaa.txt',"w"); fwrite($file,$ret); fclose($file);		
		if ($ret==true)#Blacklisted
		{
			$this->load->view('blist',$data);	
		}else#Not Blacklisted
		{
			$this->getdata_model->LoadSubscriberSession($data['Phone']);		
			
			if ($_SESSION['subscriber_email']) $data['subscriber_email']=$_SESSION['subscriber_email'];		
			if ($_SESSION['subscriber_name']) $data['subscriber_name'] = $_SESSION['subscriber_name'];
			if ($_SESSION['datecreated']) $data['datecreated'] = $_SESSION['datecreated'];
			if ($_SESSION['subscriber_status']) $data['subscriber_status'] = $_SESSION['subscriber_status'];
	
			if ($_SESSION['jwplayer_key']) $data['jwplayer_key'] = $_SESSION['jwplayer_key'];
			if ($_SESSION['distribution_Id']) $data['distribution_Id'] = $_SESSION['distribution_Id'];
			if ($_SESSION['domain_name']) $data['domain_name'] = $_SESSION['domain_name'];
			if ($_SESSION['origin']) $data['origin'] = $_SESSION['origin'];
			if ($_SESSION['thumbs_bucket']) $data['thumbs_bucket'] = $_SESSION['thumbs_bucket'];
			
			
			
			$data['subscribe_date'] = ''; $data['exp_date'] = '';
			$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
				
			$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$data['Phone']);
								
			if (is_array($result))
			{
				$td=date('Y-m-d H:i:s');
				
				foreach($result as $row)
				{
					if ($row->subscribe_date) $dt = date('F d, Y',strtotime($row->subscribe_date));
					
					$data['subscribe_date'] = $dt;
					
					if ($row->exp_date) $edt = date('F d, Y',strtotime($row->exp_date));
					$data['exp_date'] = $edt;
					
					if ($td > date('Y-m-d H:i:s',strtotime($row->exp_date)))
					{
						if ($row->subscriptionstatus==1)
						{
							#Update Subscription Date
							$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'0');
						}
					}else
					{
						if (!$row->subscriptionstatus)
						{
							$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'1');
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}else
						{
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}
					}
	
					break;
				}
			}
			
			$data['Categories']=$this->getdata_model->GetCategories();
			
			$_SESSION['Network']=$data['Network'];
			$_SESSION['Phone']=$data['Phone'];
			
			
			$data['PopularMovies']=$this->getdata_model->GetPopularMovies();
			
			$data['LatestVideos']=$this->getdata_model->GetLatestVideos();
						
			#$file = fopen('aaa.txt',"a"); fwrite($file,"OUTPUT\n======\n"); fclose($file);
						
			
			#Determine Site To Launch
			$ret=$data['Network'];
			
			$host=strtolower(trim($_SERVER['HTTP_HOST']));
	
	$file = fopen('aaa_msisdn.txt',"a"); fwrite($file, "MSISDN=".$data['Phone']); fclose($file);				
	
			if (strtolower(trim($ret))=='airtel')
			{			
				$this->load->view('subscriberhome_view',$data);			
			}elseif (strtolower(trim($ret))=='mtn')
			{
				if ($host=='localhost')
				{
					redirect('http://localhost/laffhub/Home', 'refresh');
					#redirect('http://localhost/mtnlaffhub/Subscriberhome', 'refresh');
				}else
				{
					redirect('https://laffhub.com/Home', 'refresh');
					#redirect('https://mtn.laffhub.com/Subscriberhome', 'refresh');
				}
			}elseif (strtolower(trim($ret))=='wifi')
			{
				if ($host=='localhost')
				{
					redirect('http://localhost/laffhub/Home', 'refresh');
				}else
				{
					redirect('https://laffhub.com/Home', 'refresh');
				}				
			}else
			{
				if ($host=='localhost')
				{
					redirect('http://localhost/laffhub/Home', 'refresh');
				}else
				{
					redirect('https://laffhub.com/Home', 'refresh');
				}
			}	
		}
	}
}