## PHP client library for Bits on the Run System API

A PHP client library for the [Bits on the Run][BitsOnTheRun] API.

### Documentation

Bits on the Run [API documentation][documentation].

### License

Bits on the Run API PHP client library source code is licensed under a BSD 3-Clause license.

[BitsOnTheRun]:http://www.longtailvideo.com/bits-on-the-run/
[documentation]:http://developer.longtailvideo.com/botr/
