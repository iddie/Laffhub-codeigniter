<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LaffHub::Unsubscribe From Service</title>
<link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">

<link href="<?php echo base_url();?>hcss/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/style2.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap-theme.min.css"> 

<link rel="stylesheet" href="<?php echo base_url(); ?>css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/jquery.dataTables.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/dataTables.jqueryui.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/select.bootstrap.min.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/select.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.jqueryui.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/select.jqueryui.min.css">


 <link rel="stylesheet" href="<?php echo base_url();?>css/datepicker3.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/general.css">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="<?php echo base_url();?>css/ie10-viewport-bug-workaround.css" rel="stylesheet">

<!--Javascripts-->
<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"></script>

<script src="<?php echo base_url();?>js/holder.min.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src=<?php echo base_url();?>js/html5shiv.min.js"></script>
  <script src="<?php echo base_url();?>js/respond.min.js"></script>
<![endif]-->

<script src="<?php echo base_url();?>js/ie10-viewport-bug-workaround.js"></script>

<script src="<?php echo base_url();?>js/bootbox.min.js"></script>
<script src="<?php echo base_url();?>js/s8.min.js"></script>


<script>
	var SubscriberEmail="<?php echo $subscriber_email; ?>";
	var SubscriptionDate="<?php echo $subscribe_date; ?>";
	var ExpiryDate="<?php echo $exp_date; ?>";
	var SubscriptionStatus='<?php echo $subscriptionstatus; ?>';
	var Network='<?php echo $Network; ?>';
	var Phone='<?php echo $Phone; ?>';
	var Email='<?php echo $subscriber_email; ?>';
	
	var Title='<font color="#AF4442">Unsubscription Help</font>';
	var m='';
	
	bootstrap_alert = function() {}
	bootstrap_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-danger alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#AF4442">'+message+'</font></span></div>')
	}
	
	bootstrap_Success_alert = function() {}
	bootstrap_Success_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-success alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#1B691A">'+message+'</font></span></div>')
	}

	$(document).ready(function(e) {
        $(function() {
			// clear out plugin default styling
			$.blockUI.defaults.css = {};
		});
		
		$(document).ajaxStop($.unblockUI);
					
		$('#btnUnsubscribe').click(function(e) {
			try
			{
				if (!checkForm()) return false;
			
				//Send values here
				$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p style="color:#fff; font-size:20px;"><b>Unsubscribing User. Please Wait...</b></p>',theme: true,baseZ: 2000});
				
				//Make Ajax Request
				var nt=$('#lblNetwork').html();
				var ph=$('#lblPhone').html();
				var sid=$('#lblSubscriptionId').html();
				var pl=$('#lblPlan').html();	
				
				//Initiate POST
				var uri = "<?php echo site_url('Unsubscribe/UnsubscribeUser');?>";
				var xhr = new XMLHttpRequest();
				var fd = new FormData();
				
				xhr.open("POST", uri, true);
				
				xhr.onreadystatechange = function() {
					//0-request not initialized , 1-server connection established, 2-request received, 3-processing request, 4-request finished and response is ready
					if (xhr.readyState == 4 && xhr.status == 200)
					{
						// Handle response.
						$.unblockUI();
						
						var res=$.trim(xhr.responseText).toUpperCase();
													
						if (res=='OK')
						{
							m='You Have Successfully Unsubscribed From LaffHub <b>'+pl.toUpperCase()+' Plan</b>.';
																
							bootstrap_Success_alert.warning(m);
							bootbox.alert({ 
								size: 'small', message: m, title:Title,
								buttons: { ok: { label: "Close", className: "btn-danger" } },
								callback: function() {
									window.location.reload(true);
								}
							});
						}else
						{
							m=res;
							bootstrap_alert.warning(m);
							bootbox.alert({ 
								size: 'small', message: m, title:Title,
								buttons: { ok: { label: "Close", className: "btn-danger" } }
							});
						}
					}
				};
			
				fd.append('network',nt);					
				fd.append('msisdn',ph);
				fd.append('email',SubscriberEmail);
				fd.append('subscriptionId',sid);
				fd.append('plan',pl);
				
				xhr.send(fd);// Initiate a multipart/form-data upload
								
			}catch(e)
			{
				$.unblockUI();
				var m='Subscribe User Button Click ERROR:\n'+e;
			   
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
				});
			}
		});//btnUnsubscribe.click
		
		function checkForm()
		{
			try
			 {
				var nt=$('#lblNetwork').html();
				var ph=$('#lblPhone').html();
				var sta=$('#hidStatus').val();
				var pl=$('#lblPlan').html();
				
				var edt=$('#lblExpiryDate').html();
				var exdt;
								
				if (edt)
				{
					var today=moment().format('DD MMM YYYY @ HH:mm:ss');
					exdt=moment(today).isSameOrAfter(edt);
				}				
				 
				//Network
				if (!nt)
				{
					m='Network has not been displayed. Please make sure you have active internet connection. You may also sign out and sign in again. If this persists, contact our support at <a href="mailto:support@efluxz.com">support@efluxz.com</a>.';
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					return false;
				}
				
				//Phone
				if ((!ph) && (!SubscriberEmail))
				{
					m='Subscriber phone or email has not been displayed. Please make sure you have active internet connection. You may also sign out and sign in again. If this persists, contact our support at <a href="mailto:support@efluxz.com">support@efluxz.com</a>.';
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					return false;
				}
				
				//Plan				
				if (!pl)
				{
					m='No service plane has been displayed. Please make sure you have active internet connection. If you are sure you had subscribed to LaffHub service successfully, you may also sign out and sign in again. If this persists, contact our support at <a href="mailto:support@efluxz.com">support@efluxz.com</a>.';
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					return false;
				}				
				
				//Status
				if (parseInt(sta,10) != 1)
				{
					m='Your attempt to unsubscribe from Laffhub failed. You have no active subscription on Laffhub service. Text <b>YES to 2001</b> to activate 7days/15 videos. Service costs N100. NO DATA COST.';
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					return false;
				}
									
				if (!confirm('Are you sure you want to unsubscribe from LaffHub '+pl.toUpperCase()+' plan? (Click "OK" to proceed or "CANCEL") to abort)?'))
				{
					return false;
				}
									
				return true;			
			 }catch(e)
			 {
				m='CHECK FORM ERROR:\n'+e; 
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
				});
			
				return false;
			 }
		 }//End CheckForm
		 
    });
	
</script>
</head>
<body>
<style>
.img-desc {
    background: #c5c3c4;
    padding: 10px 20px;
}
h4 {
    float: left;
}
.profile-img{
    float: left;
    width: 25%; 
}
.channel-in{
   min-height:600px;
   background:#ffffff;
}
input.form-control {
    border: 1px solid #c5c3c4;
    border-radius: 0px;
}
.img-portion img{
    width:100%;
    float:left;	
}
.former {
    margin-top: 15px;
}
.channel-wrapper input.form-control {
    width: 100%;
    height: 35px;
}
.name-type {
    position: relative;
    top: -30px;
    margin-top: 30px;
}
.channel-in2 {
    background: #fff;
    min-height: 558px;
    padding: 20px;
}
@media only screen and (min-width:768px)
{
    .base1{
	    padding-right:15px !important; 
	}
	.base2{
	    padding-left:15px !important; 
	}
}
@media only screen and (max-width:767px){
    .base1 {
        margin-bottom: 20px !important;
    }
}
i.fa.fa-check-circle {
    font-size: 35px;
    color: green;
}
p.sub {
    font-size: 19px;
    font-weight: 600;
}
p.place {
    font-size: 16px;
    font-weight: 600;
}
</style>
<header> <?php include('usernav.php'); ?> </header>

<div class="container">
 	<div class="content-wrapper">
    	<section class="content">
     		<div class="row">    
              <div class="col-md-12">
                 <div class="panel panel-info">
                 	  <!-- Default panel contents -->
                      <div class="panel-heading size-20">
                        <span class="size-18 makebold"><i class="glyphicon glyphicon-remove-circle"></i> Unsubscribe From Service </span>
                      </div>
                      
                      <div class="panel-body">                                                             
                            <form class="form-horizontal"> 
                                <!--Network/Phone Number-->
                                <div class="form-group">
                                  <!--Network-->
                                  <label for="lblNetwork" class="col-sm-2 control-label " title="<?php echo $Network; ?>">Network</label>
                
                                  <div class="col-sm-3" title="<?php echo $Network; ?>">
                                     <label style="text-transform:none; color:#EC1D22;" class="form-control" id="lblNetwork"><?php echo $Network; ?></label>
                                  </div>
                                  
                                  <!--Phone Number-->
                                  <label for="lblPhone" class="col-sm-3 control-label" title="Subscriber Phone Number">Phone No</label>
                
                                  <div class="col-sm-3" title="Subscriber Phone Number" > 
                                     <label id="lblPhone" class="form-control nobold" title="Phone Number"><?php echo $Phone; ?></label>
                                  </div>
                                </div>
                                                
                                                
                                <!--Service Plan Duration/Service Plan-->
                                <div class="form-group">
                                    <!--Service Plan-->
                                  <label for="lblPlan" class="col-sm-2 control-label" title="Service Plan">Service Plan</label>
                
                                  <div class="col-sm-3" title="Service Plan" > 
                                     <label class="form-control nobold" id="lblPlan"><?php echo $plan; ?></label>
                                  </div>
                                
                                    <!--Service Plan Duration-->
                                  <label for="lblDuration" class="col-sm-3 control-label" title="Service Plan Duration">Service Plan Duration(Days)</label>
                
                                  <div class="col-sm-3" title="Service Plan Duration"> 
                                     <label class="form-control nobold" id="lblDuration"><?php echo $duration; ?></label>
                                  </div>                                      
                                </div>
                                                
                                               
                                <!--No Of Videos To Watch/ No of Videos Watched-->
                                <div class="form-group">
                                <!--No Of Videos-->
                              <label for="lblVideoCount" class="col-sm-2 control-label" title="No Of Videos To Watch">Videos To Watch</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblVideoCount" title="No Of Videos To Watch"><?php echo $videos_cnt_to_watch; ?></label>
                              </div>
                            
                                <!--No Of Videos Watched-->
                              <label for="lblWatched" class="col-sm-3 control-label" title="No Of Videos Watched">No Of Videos Watched</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblWatched" title="No Of Videos Watched"><?php echo $Watched; ?></label>
                              </div>
                            </div>
                                            
                            <!--Subscription Date/Expiry Date-->
                            <div class="form-group">
                                <!--Subscription Date-->
                              <label for="lblSubscriptionDate" class="col-sm-2 control-label" title="Subscription Date">Subscription Date</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblSubscriptionDate" title="Subscription Date"><?php echo $SubscriptionDate; ?></label>
                              </div>
                            
                                <!--Expiry Date-->
                              <label for="lblExpiryDate" class="col-sm-3 control-label" title="Subscription Expiry Date">Subscription Expiry Date</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblExpiryDate" title="Subscription Expiry Date"><?php echo $ExpiryDate; ?></label>
                              </div>
                            </div>
                            
                            <!--Subcription Amount/Subscription Status-->
                            <div class="form-group">
                              <!--Amount-->
                              <label for="lblAmount" class="col-sm-2 control-label" title="Subscription Amount">Amount Charged (&#8358;)</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblAmount" title="Subscription Amount"><?php echo $amount; ?></label>
                              </div>
                              
                              <!--Subscription Status-->
                              <label for="lblStatus" class="col-sm-3 control-label" title="Subscription Status">Subscription Status</label>
            
                              <div class="col-sm-3"> 
                                 <label class="form-control nobold" id="lblStatus" title="Subscription Status"><?php echo $subscriptionstatus; ?></label>
                                 
                                 <input type="hidden" id="hidStatus" value="<?php echo $status; ?>">
                            </div>
                           </div>
                           
                           <!--Subscription ID-->
                            <div class="form-group">
                               <label for="lblSubscriptionId" class="col-sm-2 control-label" title="Subscription ID">Subscription ID</label>
                
                                  <div class="col-sm-3" title="Subscription ID" > 
                                     <label style="background-color:#C5522D; color:#ffffff;" id="lblSubscriptionId" class="form-control nobold"><?php echo $subscriptionId; ?></label>
                                  </div>                                  
                            </div>
                                                        
                            <div align="center">
                                <div id = "divAlert"></div>
                           </div>
                             
                            
                            <center>
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-7" style="margin-top:30px;">
                                    <button title="Unsubscription User" id="btnUnsubscribe" type="button" class="btn btn-primary" role="button" style="text-align:center; width:120px;"><i class="glyphicon glyphicon-remove-sign"></i> Unsubscribe</button>
                                                                
                                    <button onClick="window.location.reload(true);" title="Refresh Form" id="btnRefresh" type="button" class="btn btn-info" role="button" style="width:120px;  margin-left:10px;" ><i class="fa fa-refresh"></i> Refresh</button>
                                </div>
                            </div>
                            </center>
                                
                        </form>                
                  </div>
                 </div>               
                </div>	
  			</div>
  		</section>
    </div>
</div>

<?php include('userfooter.php'); ?>

<script src="<?php echo base_url();?>js/jquery-ui.min.js"></script>
 <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>

<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>

<script type='text/javascript' src="<?php echo base_url();?>js/jquery.dataTables.min.js"></script>
<script type='text/javascript' src="<?php echo base_url();?>js/dataTables.bootstrap.min.js"></script>
<script type='text/javascript' src="<?php echo base_url();?>js/dataTables.select.min.js"></script> 
<script type='text/javascript' src="<?php echo base_url();?>js/dataTables.fixedColumns.min.js"></script>

 <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
 <script src="<?php echo base_url();?>js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url();?>js/jquery-jvectormap-world-mill-en.js"></script>
 <script src="<?php echo base_url();?>js/moment.min.js"></script>
 <script src="<?php echo base_url();?>js/bootstrap-datepicker.js"></script>
 <script src="<?php echo base_url();?>js/bootstrap-datetimepicker.min.js"></script>
 <script src="<?php echo base_url();?>js/bootstrap3-wysihtml5.all.min.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>js/jquery.blockUI.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/general.js"></script>
</body>
</html>