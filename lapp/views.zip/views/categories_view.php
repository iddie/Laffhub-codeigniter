<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><?php /*?><?php */?>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LaffHub::Videos By Category</title>
<link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">
<link href="<?php echo base_url();?>hcss/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/font-awesome.min.css" rel="stylesheet">
<!--<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">-->


<link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/general.css">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="<?php echo base_url();?>css/ie10-viewport-bug-workaround.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/raterater.css" type="text/css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/general.css" type="text/css"/>

<!--Javascripts-->
<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"></script>

<script src="<?php echo base_url();?>js/holder.min.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src=<?php echo base_url();?>js/html5shiv.min.js"></script>
  <script src="<?php echo base_url();?>js/respond.min.js"></script>
<![endif]-->

<script src="<?php echo base_url();?>js/ie10-viewport-bug-workaround.js"></script>

<script>
	var Network='<?php echo $Network;?>';
	var Phone='<?php echo $Phone; ?>';
	var Email='<?php echo $subscriber_email; ?>';
	
	var Title='<font color="#AF4442">LaffHub Help</font>';
	var m='';
	
	bootstrap_alert = function() {}
	bootstrap_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-danger alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#AF4442">'+message+'</font></span></div>')
	}
	
	bootstrap_Success_alert = function() {}
	bootstrap_Success_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-success alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#1B691A">'+message+'</font></span></div>')
	}
	
	$(document).ready(function(e) {
        $(function() {
			// clear out plugin default styling
			$.blockUI.defaults.css = {};
		});
		
		$(document).ajaxStop($.unblockUI);
		
		jQuery.timeago.settings.allowFuture = true;
		jQuery("time.timeago").timeago();
    });
	
	function ShowVideo(code)
	{
		var url='<?php echo base_url(); ?>' + code;
		
		window.location.href=url;
	}
</script>
</head>
<body>

<header> <?php include('usernav.php'); ?> </header>

<div class="container paddingcont">
	<div class="wrapper2">
         <div class="row no_margin">
        
            <div class="title heading justlagh">
             <h2><?php echo $Category; ?> <i class="fa fa-chevron-right" aria-hidden="true" style="  ont-size: 20px; vertical-align: middle;"></i></h2>
            </div>
         </div>     
    </div>
    
    <div class="row no_margin">
    	<?php
			if (count($CategoryVideos)>0)
			{
				foreach($CategoryVideos as $row):
					if (trim($row->video_code) and trim($row->thumbnail))
					{
						$comedian=''; $starcnt='0 Star'; $views='';
				
						if ($row->watchcount > 1) $views=$row->watchcount.' Views'; else $views=$row->watchcount.' View';
						
						if ($row->Rating > 0)
						{
							if ($row->Rating>1) $starcnt=$row->Rating.' Stars'; else $starcnt=$row->Rating.' Star';
						}
						
						if ($row->comedian) $comedian='<h6 style="text-transform:capitalize; font-size:13px;"><b>'.ucwords(strtolower($row->comedian)).'</b></h6>';
						
						echo '
							<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12 mobilevs">
								<div class="list-div" style="height:250px;">
									<img onClick="ShowVideo(\'c-'.$row->video_code.'\');" title="Click to watch '.strtoupper($row->video_title).'" style="height:100px; cursor:pointer;" src="https://s3-us-west-2.amazonaws.com/'.$thumbs_bucket.'/'.$row->category.'/'.trim($row->thumbnail).'" class="img-responsive">
									<div class="list-div-text2">
										<h4 style="text-transform:capitalize; font-size:13px;">'.ucwords(strtolower($row->video_title)).'</h4>         
					'.$comedian.'
										<span class="size-12">
											'.$views.' <span class="bef"><time class="timeago" datetime="'.$row->date_created.'" title="'.date('F d, Y',strtotime($row->date_created)).'"></time></span>
										</span>
										<br><span class="size-12" title="Click to rate '.strtoupper($row->video_title).'"><b>Rate Video: <span title="Current Video Rating" style="color:#f00;" id="count'.trim($row->video_code).'">'.$starcnt.'</span></b> 
											<div style="display: block; cursor: pointer; margin-top:8px" class="ratebox" data-id="'.trim($row->video_code).'" data-rating="'.$row->Rating.'"></div>
										</span>
									</div>
								</div>
							  </div>						
							';
					}
				endforeach;
			}
		?>
	
    </div>
</div>

<?php include('userfooter.php'); ?>

<script src="<?php echo base_url();?>js/jquery.min.js"></script> 
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.blockUI.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/general.js"></script>
<script src="<?php echo base_url();?>js/jquery.timeago.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/raterater.jquery.js"></script>
<script src="<?php echo base_url();?>js/bootbox.min.js"></script>

<script>	
//// STAR RATING	
	/* This is out callback function for when a rating is submitted	 */
	function SaveRate(video_code, rating)
	{
		try
		{
			if (parseInt(rating,10)==0)
			{
				m='No Star Selected. Make Sure There Is A <b>Yellow Colour</b> In The Selected Star.';
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
				});
				
				return false;
			}
			
			$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p style="color:#fff; font-size:20px;"><b>Rating Video. Please Wait...</b></p>',theme: true,baseZ: 2000});
			
			var mydata={video_code:video_code,email:Email,phone:Phone,rating:rating};
			
			$.ajax({
				type: "POST",
				dataType: 'text',
				data: mydata,
				url: '<?php echo site_url('Subscriberhome/RateVideo'); ?>',
				complete: function(xhr, textStatus) {
					$.unblockUI();
				},
				success: function(data,status,xhr) //we're calling the response json array 'cntry'
				{
					$.unblockUI();
					
					if ($.trim(data.toUpperCase())=='OK')
					{
						if (rating<2)
						{
							$('#count'+video_code).html(rating+' Star');
						}else
						{
							$('#count'+video_code).html(rating+' Stars');
						}
					}else
					{
						m=data;
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
								callback:function(){
									setTimeout(function() {
										$('#divAlert').fadeOut('fast');
									}, 10000);
								}
						});
					}
				},
				error:  function(xhr,status,error) {
					$.unblockUI();
					
					m='Error '+ xhr.status + ' Occurred: ' + error;
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
					});
				}
			 }); //end AJAX
		}catch(e)
		{
			$.unblockUI();
			m='SAVE RATING ERROR:\n'+e;
			bootstrap_alert.warning(m);
			bootbox.alert({ 
				size: 'small', message: m, title:Title,
				buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
			});
		}
	}
	
	/* Here we initialize raterater on our rating boxes
	 */
	$(function() {
		$( '.ratebox' ).raterater( { 
			submitFunction: 'SaveRate', 
			allowChange: true,
			starWidth: 16,
			spaceWidth: 3,
			numStars: 5,
			step: 1,
		} );
	});
	 //// STAR RATING ENDS
</script>
</body>
</html>