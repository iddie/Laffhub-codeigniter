<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>:: Laff Hub ::</title>
<link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">
<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
</head>
<body>
<header>

<?php include('usernav.php'); ?>
 
 
  <section class="slider-div">
  <div class="container">
<div class="row">
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12 col-md-offset-1 col-lg-offset-1 col-sm-offset-1">

    <iframe width="100%" height="415" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
    <div class="row">
<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 ">
<div class="vedio-title">
<h5> Target the Hole </h5>
<p>Yeh Rishta Kya Kehlata Hai is a Hindi family drama. After her arranged marriage to Naitik Singhania, Akshara gradually falls in love with him and finds her own identity as a woman, wife and mother. Watch latest full episode of Yeh Rishta Kya Kehlata Hai on Premium at 6 PM IST same day as telecast and for Free from 7 AM IST day after telecast only on Hotstar.</p>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 ">
<ul class="social">
          <li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
          <li><a href="#" class="instagram"><i class="fa fa-instagram"></i></a></li>
          <li><a href="#" class="youtube"><i class="fa fa-youtube-square"></i></a></li>
          <li><a href="#" class="twitter"><i class="fa fa-twitter-square"></i></a></li>
          <li><a href="#" class="whatsapp"><i class="fa fa-whatsapp"></i></a></li>
        </ul>

</div>

</div>
    
    </div>
  </div>
</div>
     </section>
</header>
<div class="main-div">
<div class="container">
<div class="wrapper2">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<section class="content">
<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="title">
      <h2>Episodes <i class="fa fa-chevron-right" aria-hidden="true" style="    font-size: 20px;
    vertical-align: middle;"></i></h2>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">     <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>

      <div class="list-div-text">
        <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">   <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 9 March </h4>
        <h5>Nandini Survives </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">  <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
       <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">  <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>
  </section>
  <section class="content">
  <div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="title">
      <h2>Popular clips <i class="fa fa-chevron-right" aria-hidden="true" style="    font-size: 20px;
    vertical-align: middle;"></i></h2>
    </div>
  </div>
</div>

  <div class="row">
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">  <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">   <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 9 March </h4>
        <h5>Nandini Survives </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">   <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
    <div class="list-div">   <iframe width="100%" height="142" src="https://www.youtube.com/embed/fXLyilnixdY" frameborder="0" allowfullscreen></iframe>
      <div class="list-div-text">
        <h4> 10 March </h4>
        <h5> A Death sentence for Nandini ? </h5>
      </div>
    </div>
  </div>

  </section>
</div>
</div>
</div>
</div>
 <section class="comment">
  <div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="vedio-title">
<h5> Comments </h5>
</div>
</div>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<h6> 1 Comment </h6>
</div>
</div>
<div class="row">
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-12">
<div class="user">
<img src="images/user.png" class="img-responsive" >

</div>
</div>
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<form>
 <div class="form-group"><textarea placeholder="Add Comment" class="form-control"></textarea>
<div class="comment">
<input class="btn btn-default" type="Comment" value="Submit">
</div>
</div>
</form>
<div class="comment-socail">
<h6> Share with  </h6>

 <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <ul class="social">
          <li><a href="#" class="facebook"><i class="fa fa-facebook-official"></i></a></li>
          <li><a href="#" class="instagram"><i class="fa fa-instagram"></i></a></li>
          <li><a href="#" class="youtube"><i class="fa fa-youtube-square"></i></a></li>
          <li><a href="#" class="twitter"><i class="fa fa-twitter-square"></i></a></li>
          <li><a href="#" class="whatsapp"><i class="fa fa-whatsapp"></i></a></li>
        </ul>
      </div>
    </div>
</div>
</div>
</div>
</div>

</div>
 <hr>
</div>
    
    </div>
   
  </div>
  
</div>
     </section>
     
     
     <?php include('userfooter.php'); ?>
     
<script src="<?php echo base_url();?>js/jquery.min.js"></script> 
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
</body>
</html>