<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LaffHub::Subscriber Profile</title>
<link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">
<link href="<?php echo base_url();?>hcss/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/style2.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">


<link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap-theme.min.css">


<link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/general.css">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="<?php echo base_url();?>css/ie10-viewport-bug-workaround.css" rel="stylesheet">

<!--Javascripts-->
<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"></script>

<script src="<?php echo base_url();?>js/holder.min.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src=<?php echo base_url();?>js/html5shiv.min.js"></script>
  <script src="<?php echo base_url();?>js/respond.min.js"></script>
<![endif]-->

<script src="<?php echo base_url();?>js/ie10-viewport-bug-workaround.js"></script>

<script src="<?php echo base_url();?>js/bootbox.min.js"></script>
<script src="<?php echo base_url();?>js/s8.min.js"></script>


<script>
	var Network='<?php echo $Network;?>';
	var Phone='<?php echo $Phone; ?>';
	var Email='<?php echo $subscriber_email; ?>';
	var SubscriberEmail="<?php echo $subscriber_email; ?>";
	var SubscriptionDate="<?php echo $subscribe_date; ?>";
	var ExpiryDate="<?php echo $exp_date; ?>";
	var SubscriptionStatus='<?php echo $subscriptionstatus; ?>';
	var OldPassword='<?php echo $OldPassword; ?>';
	
	var Title='<font color="#AF4442">Update Profile Help</font>';
	var m='';
	
	bootstrap_alert = function() {}
	bootstrap_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-danger alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#AF4442">'+message+'</font></span></div>')
	}
	
	bootstrap_Success_alert = function() {}
	bootstrap_Success_alert.warning = function(message) 
	{
	   $('#divAlert').html('<div class="alert alert-success alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#1B691A">'+message+'</font></span></div>')
	}

	$(document).ready(function(e) {
        $(function() {
			// clear out plugin default styling
			$.blockUI.defaults.css = {};
		});
		
		$(document).ajaxStop($.unblockUI);	
		
		$('#chkChangePwd').click(function(e) {
            try
			{
				var chk=$(this).prop('checked');
				
				if (chk==true)
				{
					$('#divOldPwd').removeClass('hide').addClass('show')
					$('#divNewPwd').removeClass('hide').addClass('show')
					$('#divConfirmPwd').removeClass('hide').addClass('show')
				}else
				{
					$('#divOldPwd').removeClass('show').addClass('hide')
					$('#divNewPwd').removeClass('show').addClass('hide')
					$('#divConfirmPwd').removeClass('show').addClass('hide')
				}
			}catch(e)
			{
				$.unblockUI();
				m='Change Password Click ERROR:\n'+e;
				
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
				});
				
				return false;
			}
        });
		
		$('#btnUpdate').click(function(e) {
				try
				{
					if (!CheckForm()) return false;
			
					//Send values here
					$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p style="color:#fff; font-size:20px;"><b>Updating Profile. Please Wait...</b></p>',theme: true,baseZ: 2000});
					
					var nm=$.trim($('#txtName').val());
					var chk=$('#chkChangePwd').prop('checked');
					var pwdflag='No';
					var mydata;
					
					if (chk==true)
					{
						pwdflag='Yes';
						mydata={email:SubscriberEmail, subscribername:nm, pwdflag:pwdflag, Pwd:sha512($('#txtNewPwd').val())};
					}else
					{
						mydata={email:SubscriberEmail, subscribername:nm, pwdflag:pwdflag};
					}
													
					$.ajax({
						url: "<?php echo site_url('Profile/UpdateProfile');?>",
						data: mydata,
						type: 'POST',
						dataType: 'text',
						complete: function(xhr, textStatus) {							
							$.unblockUI;
						},
						success: function(data,status,xhr) {	
							$.unblockUI;
							
							$.unblockUI();
							
							if ($.trim(data).toUpperCase()=='OK')
							{
								$.unblockUI();
								
								m='Profile Update Was successful';
																
								bootstrap_Success_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } },
									callback:function(){
										window.location.reload(true);
									}
								});
							}else
							{
								$.unblockUI;
								
								m=data;
								
								bootstrap_alert.warning(m);
								bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
							}		
						},
						error:  function(xhr,status,error) {
								$.unblockUI;
							
							m='Error '+ xhr.status + ' Occurred: ' + error;
							
							bootstrap_alert.warning(m);
							bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						}
					});
					
					//$.unblockUI();
				}catch(e)
				{
					$.unblockUI();
					m='Update Button Click ERROR:\n'+e;
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
				}
            });//btnUpdate Click Ends
			
		function CheckForm()
		{
			try
			{
				var em=$.trim($('#lblEmail').html());//Email
				var nm=$.trim($('#txtName').val());
				var oldpwd=$('#txtOldPwd').val();
				var newpwd=$('#txtNewPwd').val();
				var cpwd=$('#txtConfirmPwd').val();
				var chk=$('#chkChangePwd').prop('checked');
				
				//Email
				if (!em)
				{
					m='Subscriber email field is blank. Your session may have expired. Logout and login again';
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					return false;
				}
				
				//Name				
				if (!nm)
				{
					m='Name field must not be blank.';
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					$('#txtName').focus(); return false;
				}
				
				if ($.isNumeric(nm))
				{
					m='Name field must not be a number.';
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					$('#txtName').focus(); return false;	
				}
				
				if (nm.length < 3)
				{
					m='Please enter your full name.';
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
					
					$('#txtName').focus(); return false;	
				}					
				
				
				if (chk==true)
				{
					//Old Password
					if (!$.trim(oldpwd))
					{
						m='Old password field must not be blank';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtOldPwd').focus(); return false;
					}
					
					if (sha512(oldpwd) != OldPassword)
					{
						m='Old password entered is not correct!';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtOldPwd').focus();  return false;
					}
					
					//New Password
					if (!$.trim(newpwd))
					{
						m='New password field must not be blank.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtNewPwd').focus(); return false;
					}
					
					if (newpwd.length<6)
					{
						m='Minimum new password size is six (6) characters.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtNewPwd').focus(); return false;
					}
					
					//Confirm Password
					if (!$.trim(cpwd))
					{
						m='Confirm password field must not be blank.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtConfirmPwd').focus();   return false;
					}
					
					if (newpwd != cpwd)
					{
						m='Password and confirming password fields do not match.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } },
							callback:function(){
								setTimeout(function() {
									$('#divAlert').fadeOut('fast');
								}, 10000);
							}
						});
						
						$('#txtConfirmPwd').focus();   return false;
					}	
				}
								
				//Confirm Registration
				if (!confirm('Do you want to proceed with the profile update? (Click OK to proceed or CANCEL to abort)'))
				{
					return false;
				}
				
				return true;
			}catch(e)
			{
				$.unblockUI();
				m='CheckForm ERROR:\n'+e;
				
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } },
					callback:function(){
						setTimeout(function() {
							$('#divAlert').fadeOut('fast');
						}, 10000);
					}
				});
				
				return false;
			}
		}
		
		$('#btnLogOut').click(function(e) {
            try
			{
				if (!confirm('Do you want to log out? (Click OK to proceed or CANCEL to abort)'))
				{
					return false;
				}
				
				window.location.href='<?php echo site_url('Subscriberlogout'); ?>';
			}catch(e)
			{
				$.unblockUI();
				m='Log Out Button Click ERROR:\n'+e;
				
				bootstrap_alert.warning(m);
				bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } },
						callback:function(){
							setTimeout(function() {
								$('#divAlert').fadeOut('fast');
							}, 10000);
						}
					});
			}
        });
    });
	

</script>
</head>
<body>
<style>
.img-desc {
    background: #c5c3c4;
    padding: 10px 20px;
}
h4 {
    float: left;
}
.profile-img{
    float: left;
    width: 25%; 
}
.channel-in{
   min-height:600px;
   background:#ffffff;
}
input.form-control {
    border: 1px solid #c5c3c4;
    border-radius: 0px;
}
.img-portion img{
    width:100%;
    float:left;	
}
.former {
    margin-top: 15px;
}
.channel-wrapper input.form-control {
    width: 100%;
    height: 35px;
}
.name-type {
    position: relative;
    top: -30px;
    margin-top: 30px;
}
.channel-in2 {
    background: #fff;
    min-height: 558px;
    padding: 20px;
}
@media only screen and (min-width:768px)
{
    .base1{
	    padding-right:15px !important; 
	}
	.base2{
	    padding-left:15px !important; 
	}
}
@media only screen and (max-width:767px){
    .base1 {
        margin-bottom: 20px !important;
    }
}
i.fa.fa-check-circle {
    font-size: 35px;
    color: green;
}
p.sub {
    font-size: 19px;
    font-weight: 600;
}
p.place {
    font-size: 16px;
    font-weight: 600;
}
</style>
<header> <?php include('usernav.php'); ?> </header>

<div class="container">
 	<div class="content-wrapper">
    	<section class="content">
         	<div class="row">
            	<div class="col-lg-12 col-md-12  col-sm-12">
                	<div class="panel panel-info">
                      <!-- Default panel contents -->
                      <div class="panel-heading size-20">
                        <span class="size-22 makebold"><i class="material-icons" style="font-size:22px; margin-top:7px;">account_box</i> PROFILE </span>
                      </div>
                      
                       <div class="panel-body">
                       		<div class="row">
                            <form class="form-horizontal">
                                 <!--Left Column-->
                                <div class="col-md-6">
                                   <center><span class="size-18 makebold" style="color:#2C86B9;">Profile Details </span></center><br>
                                    
                                    <div class="form-group" title="Your fullname">
                                        <label for="lblEmail" class="col-sm-3 control-label ">Email</label>
                                        
                                        <div class="col-sm-9">
                                        <label id="lblEmail" class="form-control nobold" ><?php echo $subscriber_email; ?></label>
                                        </div>
                                    </div>
                                
                                    <div class="form-group"  title="Your fullname">
                                        <label for="txtName" class="col-sm-3 control-label">Fullname</label>
                                        
                                        <div class="name-type col-sm-9">
                                        	<input style="color:#686868; font-weight:normal;" id="txtName" type="text" class="form-control" placeholder="Your fullname"  value="<?php echo $subscriber_name; ?>">
                                        </div>
                                    </div>
                                
                                    <div class="form-group">			     
                                        <label class="col-sm-12 col-sm-offset-3">
                                            <input id="chkChangePwd" type="checkbox"><span class="redtext size-16">&nbsp;&nbsp;<b>Change Password</b></span>
                                        </label>
                                    </div>	
                                
                                    <div id="divOldPwd" title="Your Current Password" class="form-group hide">
	                                    <label for="txtOldPwd" class="col-sm-3 control-label">Old Password</label>
                                        
                                        <div class="name-type col-sm-9">
                                         	<input id="txtOldPwd" type="password" class="form-control nobold" placeholder="Your Current Password">
                                        </div>                                        
                                    </div>	
                                
                                    <div id="divNewPwd" title="Your New Password" class="form-group hide">
                                    	<label for="txtNewPwd" class="col-sm-3 control-label">New Password</label>
                                        
                                        <div class="name-type col-sm-9">
                                        	<input id="txtNewPwd" type="password" class="form-control" placeholder="Your New Password">
                                        </div>                                        
                                    </div>	
                                
                                    <div id="divConfirmPwd" title="Confirm Your New Password" class="form-group hide">
                                    	<label for="txtConfirmPwd" class="col-sm-3 control-label">Retype Password</label>
                                        <div class="name-type col-sm-9">
                                        	<input id="txtConfirmPwd" type="password" class="form-control" placeholder="Confirm Your New Password">
                                        </div>
                                        
                                    </div>
                                
                                    <div align="center" class="form-group">
                                        <div id = "divAlert"></div>
                                    </div>
                    
                               		<div class="form-group">
                                        <!--<input type="submit" class="btn btn-info form-control" value="UPDATE PROFILE">-->
                                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 col-sm-offset-2">
                                            <button id="btnUpdate" class="btn btn-info form-control"><i class="glyphicon glyphicon-edit"></i> UPDATE PROFILE</button>
                                         </div>
                                         
                                         <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">
                                            <button onClick="window.location.reload(true);" class="btn btn-warning form-control"><i class="glyphicon glyphicon-refresh"></i> REFRESH</button>
                                         </div>
                                    </div>
                                </div>
                                
                                <!--Right Column-->
                                <div class="col-md-6">
                                    <center><span class="size-18 makebold" style="color:#2C86B9;"> Subscription Information </span></center><br>
                                    
                                   	<div title="Last Subscription Date" class="form-group">
                                        <label class="place col-sm-5 control-label" for="lblLastSubscriptionDate">Last Subscription Date:</label>                                           
                                         <div class="col-sm-6">
                                            <label id="lblLastSubscriptionDate" class="form-control nobold"><?php echo $subscribe_date; ?></label> 
                                        </div>                                       
                                    </div>
                                    
                                    <div title="Subscription Expiry Date" class="form-group">
                                        <label class="col-sm-5 control-label" for="lblExpiryDate">Subscription Expiry Date:</label>  
                                            
                                         <div class="col-sm-6">
                                            <label id="lblExpiryDate" class="form-control nobold"><?php echo $exp_date; ?></label> 
                                        </div>
                                    </div>
                                    
                                    <div title="Subscription Status" class="form-group">
                                        <label class="control-label col-sm-5" for="lblStatus">Subscription Status:</label>  
                                            
                                         <div class="col-sm-6">
                                            <label id="lblStatus" class="form-control nobold"><?php echo $subscriptionstatus; ?></label> 
                                        </div> 
                                    </div>
                                    
                                    <div style="margin-top:30px;" class="col-sm-6 col-sm-offset-5 former">
                                    <button id="btnLogOut" class="btn btn-danger form-control"><i class="fa fa-sign-out"></i> LOGOUT</button>
                                	</div>
                                 </div>
                            </form>
                            </div>
                       </div>
                    </div>                    	
                </div>                
 			 </div>
        </section>
    </div>
</div>

<?php include('userfooter.php'); ?>

<script src="<?php echo base_url();?>js/jquery.min.js"></script> 
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.blockUI.js"></script> 
<script type='text/javascript' src="<?php echo base_url();?>js/s8.min.js"></script>
</body>
</html>