<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    
    <link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">
    
    <title>LaffHub | Videos</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <?php include('homelink.php'); ?>
    
    <script>
		bootstrap_alert = function() {}
		bootstrap_alert.warning = function(message) 
		{
		   $('#divAlert').html('<div class="alert alert-danger alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#AF4442">'+message+'</font></span></div>')
		}
				
		bootstrap_Success_alert = function() {}
		bootstrap_Success_alert.warning = function(message) 
		{
		   $('#divAlert').html('<div class="alert alert-success alert-dismissable fade in show"><button type="button" class="close" data-dismiss="alert" aria-label="close" aria-hidden = "true">&times;</button><span><font color="#1B691A">'+message+'</font></span></div>')
		}
		
		var Title='<font color="#AF4442">Video Module Help</font>';
		var m='';
		
		var Username='<?php echo $username; ?>';
		var UserFullName='<?php echo $UserFullName; ?>';
		var table,editdata,seldata;
		
		var videotitle,videoid,category,streamlink,filename;
		var video_file=null;
		
		function GetFile(input,SelectedFile)
		{
			try
			{
				$('#divAlert').html('');
				$('#vidTrailer').removeClass('show');
				$('#vidTrailer').addClass('hidden');
								
				if ($.trim(SelectedFile)=='Video')
				{
					video_file=null;
					
					if (input.files && input.files[0]) video_file=input.files[0];
					
					if (video_file != null)
					{
						if (window.File && window.FileReader && window.FileList && window.Blob) 
						{
							var video = document.getElementById("vidTrailer");
							
							//THE METHOD THAT SHOULD SET THE VIDEO SOURCE
							if (input.files && input.files[0]) {
								$('#vidTrailer').removeClass('hidden');
								$('#vidTrailer').addClass('show');
								
								var file = input.files[0];
								var url = URL.createObjectURL(file);
								//console.log(url);
								var reader = new FileReader();
								reader.onload = function() {
									var fsize = file.size;
									
									if(fsize>41943040) //do something if file size more than 40 mb (1048576-1MB)
									{
										m=number_format((fsize/1048576),0,'.',',') + " MB is too large for a trailer file!";
										bootstrap_alert.warning(m);
										bootbox.alert({ 
											size: 'small', message: m, title:Title,
											buttons: { ok: { label: "Close!", className: "btn-danger" } }
										});
										
										video.src = '';
										$('#txtVideo').val('');
										
										return false;
									}else
									{
										video.src = url;
										//video.play();
									}
								}
								reader.readAsDataURL(file);
							}	
						}else
						{
							m="Please upgrade your browser, because your current browser lacks some new features we need!";
							bootstrap_alert.warning(m);
							bootbox.alert({ 
								size: 'small', message: m, title:Title,
								buttons: { ok: { label: "Close!", className: "btn-danger" } }
							});
							
							return false;
						}	
					}					
				}
			}catch(e)
			{
				m='GETFILE ERROR:\n'+e;
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close!", className: "btn-danger" } }
				});
			}
		} //End GetFile
						
    	$(document).ready(function(e) {
			$(function() {
				// clear out plugin default styling
				$.blockUI.defaults.css = {};
			});
		
        	$(document).ajaxStop($.unblockUI);
			
			$('#btnCloseModal').click(function(e) {
                try
				{
					var video = document.getElementById("vidModal");						
					video.src = '';
				}catch(e)
				{
					$.unblockUI();
					m="Modal Close Button Click ERROR:\n"+e;
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } }
					});
				}
            });
			
			table = $('#recorddisplay').DataTable( {
					 select: true,
					dom: '<"top"if>rt<"bottom"lp><"clear">',
					language: {zeroRecords: "No Record Found"},
					columnDefs: [ 
						{
							"targets": [ 0,1,2,3,4,5 ],
							"visible": true,
							"searchable": true
						},
						{
							"targets": [ 2,3,5 ],
							"searchable": true,
							"orderable": true
						},
						{
							"targets": [ 6,7,8,9 ],
							"visible": false,
							"searchable": false
						},
						{
							"targets": [ 0,1,4 ],
							"orderable": false,
							"searchable": false
						},
						{ className: "dt-center", "targets": [ 0,1,2,3,4,5 ] }
					],// 'SELECT','DELETE',video_title,category,'VIDEO',video_status,streaming_link,video_id,filename
					columns: [
						{ width: "5%" },//Select
						{ width: "5%" },//Delete
						{ width: "60%" },//video_title
						{ width: "10%" },//Category
						{ width: "10%" },//[VIDEO]
						{ width: "10%" },//status
						{ width: "0%" },//link
						{ width: "0%" },//video Id
						{ width: "0%" },//filename
						{ width: "0%" }//status
					],
					order: [[ 0, 'asc' ]],
					ajax: {
					  	url: '<?php echo site_url('Videos/LoadVideosJson'); ?>',
						type: 'POST',
						dataType: 'json'
				   }
				} );
				
			// Add event listener for opening and closing details
			$('#recorddisplay tbody').on('click', 'td', function () {
				var tr = $(this).closest('tr');
				var row = table.row( tr );
				editdata = row.data();
				
				var colIndex = $(this).index();
				
				if (colIndex==0) SelectRow(editdata);
			} );	
			
			$('#recorddisplay tbody').on( 'click', 'tr', function () 
			{							
				if ( $(this).hasClass('selected') ) {
					$(this).removeClass('selected');
					
					if (document.getElementById('btnEdit')) document.getElementById('btnEdit').disabled=false;
					if (document.getElementById('btnAdd')) document.getElementById('btnAdd').disabled=true;

					//alert('Select');
					//Get Selected Value					
					var val=table.row( this ).data();
					seldata=val;
					var tit=val[2],cat=val[3],vid=val[4],sta=val[5],strm=val[6],id=val[7],fn=val[8],st=val[9];
					
//'SELECT','DELETE',video_title,category,'VIDEO',video_status,streaming_link,video_id,filename,status	
					
					$('#txtTitle').val(tit);
					$('#cboCategory').val(cat);
					$('#cboStatus').val(st);
					$('#txtLink').val(strm);
					$('#hidMovieId').val(id);
					$('#hidFilename').val(fn);
				}
				else 
				{					
					table.$('tr.selected').removeClass('selected');
					$(this).addClass('selected');
					//alert('UnSelect');
					
					ResetControls();
				}
			} );
			
			$('#recorddisplay tbody').on( 'click', 'tr', function () {
				$(this).toggleClass('selected');
			} );
			
						
			$('#btnEdit').click(function(e) {
				try
				{
					var un,fn,ln,em,ph,sta,rl,pem,dt,pwd,uvid,cusr,spar,vlog,st;
					
					if (editdata)
					{
						un=editdata[2],fn=editdata[3],ln=editdata[4],em=editdata[5],ph=editdata[6],sta=editdata[7],rl=editdata[8],pem=editdata[9],dt=editdata[10],pwd=editdata[11],uvid=editdata[12],cusr=editdata[13],spar=editdata[14],vlog=editdata[15],st=editdata[16];
						
						if (!un)
						{
							m='Please select the record you want to edit by clicking on the row containing the user account record in the table in VIEW USERS tab and modify the required data before continuing with the editing.';
						
							bootstrap_alert.warning(m);
							bootbox.alert({ 
								size: 'small', message: m, title:Title,
								buttons: { ok: { label: "Close", className: "btn-danger" } }
							});
									
							return false;
						}
					}else
					{
						m='Please select the record you want to edit by clicking on the row containing the user account record in the table in VIEW USERS tab and modify the required data before continuing with the editing.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
								
						return false;
					}
					
					if (!CheckForm('edit')) return false;
					
					m=''
					
					$('#divAlert').html('');
					
					//Send values here
					$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p>Editing User Account. Please Wait...</p>',theme: true,baseZ: 2000});
										
					//Make Ajax Request					
					var un=$.trim($('#txtUsername').val());
					var fn=$.trim($('#txtFirstname').val());
					var ln=$.trim($('#txtLastname').val());	
					var ph=$.trim($('#txtPhone').val());
					var em=$.trim($('#txtEmail').val());
					var rl=$('#cboRole').val();
					var sta=$('#cboStatus').val();
					var cuser='0',uvideo='0',spara='0',vlog='0';
					
					if ($('#chkCreateUser').prop('checked')) cuser='1';
					if ($('#chkSetParameters').prop('checked')) spara='1';
					if ($('#chkUpload_Video').prop('checked')) uvideo='1';
					if ($('#chkViewLogReport').prop('checked')) vlog='1';
					
					var mydata={username:un, firstname:fn, lastname:ln, email:em, phone:ph, accountstatus:sta, role:rl, Upload_Video:uvideo, CreateUser:cuser, SetParameters:spara, ViewLogReport:vlog, User:Username,UserFullname:UserFullName};
										
					$.ajax({
						url: "<?php echo site_url('Videos/EditVideos');?>",
						data: mydata,
						type: 'POST',
						dataType: 'text',
						complete: function(xhr, textStatus) {
							//$.unblockUI;
						},
						success: function(data,status,xhr) {	
							$.unblockUI();
							
							if ($.trim(data)=='OK')
							{
								$.unblockUI();
																
								m='User Account "'+un.toUpperCase()+'('+fn.toUpperCase()+' '+ln.toUpperCase()+')" Was Edited successfully.';
								
								table.ajax.reload();
								
								ResetControls();
										
								bootstrap_Success_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}else
							{
								$.unblockUI();
								
								m=data;
								
								bootstrap_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}		
						},
						error:  function(xhr,status,error) {
								$.unblockUI();
								
								m='Error '+ xhr.status + ' Occurred: ' + error;
								bootstrap_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}
					});
					
					//$.unblockUI();
				}catch(e)
				{
					$.unblockUI();
					m='Edit Button Click ERROR:\n'+e;
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } }
					});
				}
            });//btnEdit Click Ends
			
			$('#btnAdd').click(function(e) {
				try
				{
					if (!CheckForm('create')) return false;
					
					m='';
					
					//Send values here
					$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p>Creating User Account. Please Wait...</p>',theme: true,baseZ: 2000});
					
					$('#divAlert').html('');
										
					//Make Ajax Request
					var un=$.trim($('#txtUsername').val());
					var fn=$.trim($('#txtFirstname').val());
					var ln=$.trim($('#txtLastname').val());	
					var ph=$.trim($('#txtPhone').val());
					var em=$.trim($('#txtEmail').val());
					var rl=$('#cboRole').val();
					var sta=$('#cboStatus').val();
					var pwd=$('#txtPwd').val();
					var cpwd=$('#txtConfirmPwd').val();
					var cuser='0',uvideo='0',spara='0',vlog='0';
					
					if ($('#chkCreateUser').prop('checked')) cuser='1';
					if ($('#chkSetParameters').prop('checked')) spara='1';
					if ($('#chkUpload_Video').prop('checked')) uvideo='1';
					if ($('#chkViewLogReport').prop('checked')) vlog='1';
															
					var mydata={username:un, firstname:fn, lastname:ln, email:em, phone:ph, accountstatus:sta, role:rl, Upload_Video:uvideo, CreateUser:cuser, SetParameters:spara, ViewLogReport:vlog, pwd:sha512($('#txtPwd').val()),User:Username,UserFullname:UserFullName};
																									
					$.ajax({
						url: "<?php echo site_url('Videos/AddVideos');?>",
						data: mydata,
						type: 'POST',
						dataType: 'text',
						complete: function(xhr, textStatus) {
							//$.unblockUI;
						},
						success: function(data,status,xhr) {	
							$.unblockUI();
							
							var ret=$.trim(data);
		
							if (ret.toUpperCase() == 'OK')
							{
								m='User Account "'+un.toUpperCase()+'('+fn.toUpperCase()+' '+ln.toUpperCase()+')" Was Created successfully.';
								
								ResetControls();
								
								table.ajax.reload();
								
								bootstrap_Success_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}else
							{
								m=data;
								
								bootstrap_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}
				
						},
						error:  function(xhr,status,error) {
								$.unblockUI;
								m='Error '+ xhr.status + ' Occurred: ' + error;
								
								bootstrap_alert.warning(m);
								bootbox.alert({ 
									size: 'small', message: m, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
							}
					});
					
					//$.unblockUI();
				}catch(e)
				{
					$.unblockUI();
					m='Create User Button Click ERROR:\n'+e;
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } }
					});
				}
            });//btnAdd Click Ends
			
			function CheckForm(par)
			{
				try
				{
					var tit=$.trim($('#txtTitle').val());
					var cat=$.trim($('#cboCategory').val());
					var sta=$.trim($('#cboStatus').val());	
					var lnk=$.trim($('#txtLink').val());
					
					if (!Username)
					{
						m='Your username is not set. Your current session may have timed out. Please refresh the page. If this error persists, sign out and sign in again.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
					}
					
					//Video Title
					if (!tit)
					{
						m='Movie title field must not be blank.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						$('#txtTitle').focus(); return false;
					}
					
					if ($.isNumeric(tit))
					{
						m='Movie title field must not be a number.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						$('#txtTitle').focus(); return false;
					}
					
					//Category
					if ($('#cboCategory > option').length < 2)
					{
						m='No movie category has been captured into the database. Please contact the system administrator.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						$('#cboCategory').focus(); return false;
					}
					
					if (!cat)
					{
						m='Please select the movie categroy.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						$('#cboCategory').focus(); return false;
					}
					
					//Video Status
					if (!sta)
					{
						m='Please select the movie status.';
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						$('#cboStatus').focus(); return false;
					}
					
					//Video
					if (video_file == null)
					{
						m="Please select the video.";
						
						bootstrap_alert.warning(m);
						bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
						
						$('#idReport').removeClass('active');
						$('#idData').addClass('active'); $('#idData').trigger('click');
						
						return false;
					}
					
					//Confirm Registration
					if (!confirm('Are you sure you want to '+fn+' this video record (Click "OK" to proceed or "CANCEL") to abort)?'))
					{
						return false;
					}
					
					return true;
				}catch(e)
				{
					$.unblockUI();
					m='CheckForm ERROR:\n'+e;
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
						size: 'small', message: m, title:Title,
						buttons: { ok: { label: "Close", className: "btn-danger" } }
					});
					
					return false;
				}
			}
        });//End document ready
		
		
		function ResetControls()
		{
			try
			{
				video_file=null;
							
				if (document.getElementById('btnEdit')) document.getElementById('btnEdit').disabled=true;
				if (document.getElementById('btnAdd')) document.getElementById('btnAdd').disabled=false;
				
				$('#txtTitle').val('');
				$('#cboCategory').val('');
				$('#cboStatus').val('');
				$('#txtLink').val('');
				$('#hidMovieId').val('');
				$('#hidFilename').val('');
				
				$('#vidTrailer').removeClass('show');
				$('#vidTrailer').addClass('hidden');
				
				var video = document.getElementById("vidTrailer");						
				video.src = '';
			}catch(e)
			{
				$.unblockUI();
				m="ResetControls ERROR:\n"+e;
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } }
				});
			}
		}//End ResetControls
				
		function DeleteRow(uname,fullname)
		{			
			try
			{
				if (!uname)
				{
					m='There is a problem with the selected row. Click on REFRESH button to refresh the page. If this message keeps coming up, please contact us at support@laffhub.com.';
					
					bootstrap_alert.warning(m);
					bootbox.alert({ 
							size: 'small', message: m, title:Title,
							buttons: { ok: { label: "Close", className: "btn-danger" } }
						});
							
					return false;
				}else
				{
					if (!confirm('Are you sure you want to delete the user account "'+uname.toUpperCase()+'('+fullname.toUpperCase()+')" from the database?. Please note that this action is irreversible. To continue, click "OK" otherwise, click "CANCEL".'))
					{
						return false;
					}else//Delete
					{
						//Send values here
						$.blockUI({message: '<img src="<?php echo base_url();?>images/loader.gif" /><p>Deleting User Account. Please Wait...</p>',theme: true,baseZ: 2000});
					
						$('#divAlert').html('');
						
						m=''
						
						//Make Ajax Request			
						var mydata={username:uname,fullname:fullname,UserFullName:UserFullName,User:Username};
						
						$.ajax({
							url: '<?php echo site_url('Videos/DeleteVideos'); ?>',
							data: mydata,
							type: 'POST',
							dataType: 'text',
							complete: function(xhr, textStatus) {
								//$.unblockUI();
							},
							success: function(data,status,xhr) {				
								//Clear boxes							
								if ($.trim(data)=='OK')
								{
									ResetControls();
									
									$.unblockUI();
																	
									table.ajax.reload( function ( json ) {
										m='User Account "'+uname.toUpperCase()+'('+fullname.toUpperCase()+')" Was Deleted successfully.';
										
										bootstrap_Success_alert.warning(m);
										bootbox.alert({ 
											size: 'small', message: m, title:Title,
											buttons: { ok: { label: "Close", className: "btn-danger" } }
										});
									} );
								}else
								{
									$.unblockUI();
									
									m=data;
									
									bootstrap_alert.warning(m);
									bootbox.alert({ 
										size: 'small', message: m, title:Title,
										buttons: { ok: { label: "Close", className: "btn-danger" } }
									});
								}
							},
							error:  function(xhr,status,error) {
								bootstrap_alert.warning('Error '+ xhr.status + ' Occurred: ' + error);
								bootbox.alert({ 
									size: 'small', message: 'Error '+ xhr.status + ' Occurred: ' + error, title:Title,
									buttons: { ok: { label: "Close", className: "btn-danger" } }
								});
								}
						});	
					}
				}
			}catch(e)
			{
				$.unblockUI();
				m='Delete Video Button Click ERROR:\n'+e;
				
				bootstrap_alert.warning(m);
				bootbox.alert({ 
					size: 'small', message: m, title:Title,
					buttons: { ok: { label: "Close", className: "btn-danger" } }
				});
			}
		}
		
		function SelectRow(dat)
		{
			if (dat)
			{
				var tit=dat[2],cat=dat[3],vid=dat[4],sta=dat[5],strm=dat[6],id=dat[7],fn=dat[8],st=dat[9];
					
//'SELECT','DELETE',video_title,category,'VIDEO',video_status,streaming_link,video_id,filename,status	
					
				$('#txtTitle').val(tit);
				$('#cboCategory').val(cat);
				$('#cboStatus').val(st);
				$('#txtLink').val(strm);
				$('#hidMovieId').val(id);
				$('#hidFilename').val(fn);
				
				$('#idReport').removeClass('active');
				$('#idData').addClass('active');					
				$('#idData').trigger('click');
			}else
			{
				ResetControls();
			}
		}
		
		function ShowVideo(title,filename)
		{
			var src='<video style="margin-top:-70px;" id="vidModal" width="530" controls autoplay><source id="srcModal" src="<?php echo base_url(); ?>video_files/'+filename+'" type="video/mp4" media="all and (max-width: 530px)">Your browser does not support the video tag.</video>';
	//alert(src);							
			$('#idModalTitle').html(title);
			$('#idModalBody').html(src);
			$('#divVideoModal').modal('show');
		}
    </script>
  </head>
  <body class="hold-transition skin-yellow sidebar-mini">
  	   
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini" style="font-size:15px;"><b>LaffHub</b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img style="margin-top:-10px; margin-left:-10px;" src="<?php echo base_url();?>images/header_logo.png" /></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
             	  

			   <li class="dropdown user user-menu" title="User Role">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  Role:&nbsp;&nbsp;<span class="hidden-xs"><?php echo $role; ?></span>
                </a>
              </li>
               
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <span class="glyphicon glyphicon-user"></span> <span id="spnUserFullname" class="hidden-xs"><?php echo $UserFullName.' ('.$username.')';?></span>
                </a>
                <ul class="dropdown-menu btn-primary">
                  <!-- User name -->
                  <li class="user-body" title="Username">
                    <p><b>Username:</b> <?php echo '<span class="yellowtext">'.$username.'</span>'; ?></p>
                  </li>
                  
                   <!-- Fullname -->
                  <li class="user-body" title="User FullName">
                    <p><b>Full Name:</b> <span id="spnUserFullname1"><?php echo '<span class="yellowtext">'.$UserFullName.'</span>'; ?></span></p>
                  </li>
                  
                 <!--Role-->
				 <li class="user-body"  title="User Role">  	
                    <p><b>Role:</b> <?php echo '<span class="yellowtext">'.$role.'</span>'; ?></p>
                </li>
                     <!--Category End-->          
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-right">
                      <a href="<?php echo site_url("Logout"); ?>" class="btn btn-danger btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
              
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
     <?php include('sidemenu.php'); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
         <h4>
            
          </h4>
          
          <ol class="breadcrumb size-16">
            <li><a href="<?php echo site_url("Logout"); ?>"><i class="fa fa-home"></i> Home</a></li>
          </ol>
        </section>
        
       

        <!-- Main content -->
        <section class="content">
        	<div class="row">     
          		<div class="col-md-12">
          			<div class="panel panel-info">
          	  <!-- Default panel contents -->
              <div class="panel-heading size-20"><i class="fa fa-file-video-o"></i> Videos</div>
                <div class="panel-body">                
              	<!--Tab-->
                <ul class="nav nav-tabs " style="font-weight:bold;">
                  <li  role="presentation" class="active"><a id="idData" data-toggle="tab" href="#tabData"><i class="material-icons">select_all</i> Video Data</a></li>
                  <li role="presentation"><a id="idReport" data-toggle="tab" href="#tabReport"><i class="fa fa-eye"></i> View Videos</a></li>
                </ul>
    			<!--Tab Ends-->
                
                <!--Tab Details-->
				<div class="tab-content">
                	<div id="tabData" class="row tab-pane fade in active ">
                    	<div class="table-responsive">
                        	
                               <div align="center" class="size-14 " style="font-style:italic; font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, sans-serif; margin-top:10px;">Fields With <span class="redtext">*</span> Are Required!</div>
                           
                            
                      		<br><form class="form-horizontal">                                                  
                              <!--Video Title-->
                              <div class="form-group" title="Enter Video Title">
                                <label class="col-sm-2 control-label  left" for="txtTitle">Video Title<span class="redtext">*</span></label>
                                <div class="col-sm-9">
                                  <input id="txtTitle" type="text" class="form-control" required="required" placeholder="Video Title">
                                  <input type="hidden" id="hidMovieId">
                                  <input type="hidden" id="hidFilename">
                                </div>
                              </div>
                              
                              <!--Video Category/Video Status-->
                            <div class="form-group">
                                <label class="col-sm-2 control-label  left" for="cboCategory" title="Select Video Category">Video Category<span class="redtext">*</span></label>
                                <div class="col-sm-3" title="Select Video Category">
                                   <select id="cboCategory" class="form-control">
                                   		<?php
										if (count($VideoCategories)>0)
										{
											echo '<option value="">[SELECT]</option>';
										
											foreach($VideoCategories as $row):
												if ($row->category)
												{
													echo '<option value="'.$row->category.'">'.$row->category.'</option>';
												}
											endforeach;
										}
									?>
                                   </select>
                                </div>
                                
                                <!--Video Status-->
                                <label class="col-sm-3 control-label " for="cboStatus" title="Select Video Status">Video Status<span class="redtext">*</span></label>
                                <div class="col-sm-3" title="Select Video Status">
                                  <select id="cboStatus" class="form-control">
                                	<option value="">[SELECT]</option>
                                    <option value="1">Active</option>
                                    <option value="0">Disabled</option>
                                </select>
                                </div>
                              </div>                          

                         
                         <!--streaming_link-->
                           <div class="form-group" title="Enter Video Streaming Link">
                           <!--Password-->
                            <label class="col-sm-2 control-label" for="txtLink">Streaming Link</label>
                            <div class="col-sm-9">
                                <textarea id="txtLink" rows="2" class="form-control" placeholder="Video Streaming Link"></textarea>
                            </div>
                        </div>
                               
                            <!--Video--> 
                  		 <div class="form-group">
                        	<label class="col-sm-2 control-label left" for="txtVideo">Video<span class="redtext">*</span></label>
                              <div align="center" class="col-sm-9">
                                <input style="margin-top:5px;" id="txtVideo" name="txtVideo" type="file" accept="video/mp4" onchange="GetFile(this,'Video');"><br>
                                
                                <video class="hidden" id="vidTrailer" width="480" controls > 
                                   <source id="srcMP4" src="" type="video/mp4" media="all and (max-width: 480px)">
                                  Your browser does not support the video tag.
                                </video>
                              </div>
                          </div>                    
    </form>
                    </div>
                </div><!--End Of Tab Content 1-->
              
              <!--Table Tab Content-->
                    <div id="tabReport" class="tab-pane fade">
                    <center>
                        <div class="table-responsive" style="margin-top:20px; ">
                        <table align="center" id="recorddisplay" cellspacing="0" title="Videos Records" class="hover display table table-bordered stripe table-condensed"  style="border:solid; width:100%;">
                              <thead style="color:#ffffff; background-color:#7E7B7B;">
                                <tr>
                                 	<th></th>
                                    <th></th>
                                    <th>VIDEO&nbsp;TITLE</th>
                                    <th>CATEGORY</th>
                                    <th>VIDEO</th>                                   
                                    <th>VIDEO&nbsp;STATUS</th> 
                                    <th>LINK</th>                               
                                    <th>VIDEO_ID</th> 
                                    <th>FILENAME</th> 
                                    <th>STATUS</th> 
                                </tr>
                              </thead>
                          </table>
                    	</div>
                       </center>
                </div><!--Table Tab Content-->
              
                <div align="center" style="margin-top:10px;">
                    <div id = "divAlert"></div>
               </div>
                                   
                 
                <div align="center" style="margin-top:30px;">
                <button title="Add Video Record" id="btnAdd" type="button" class="btn btn-primary " role="button" style="text-align:center; width:150px;"><i class="glyphicon glyphicon-plus"></i> Add Video Record</button>
                
                <button disabled title="Edit Video Record" id="btnEdit" type="button" class="btn btn-primary" role="button" style="text-align:center; width:150px; padding-left:20px; padding-right:20px;">
                    <span class="ui-button-text"><span class="glyphicon glyphicon-edit" ></span> Edit Video Record</span>
                </button>
                                                                            
                <button  onClick="window.location.reload(true);" title="Refresh Form" id="btnRefresh" type="button" class="btn btn-danger" role="button" style="text-align:center; width:150px;"><span class="glyphicon glyphicon-refresh" ></span> Refresh</button>
                </div>
            </div>
                           
              </div>
          </div>
        		</div>        
      		</div><!-- /.row -->
        </section><!-- /.row (main row) -->
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
        <strong>Copyright &copy; <?php echo date('Y');?> <a href="">LaffHub</a>.</strong> All rights reserved.
      </footer>

      
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
   
    <script src="<?php echo base_url();?>js/jquery-ui.min.js"></script>
     <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    
    <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <!--<script src="<?php echo base_url();?>js/raphael-min.js"></script>-->
  	 <!--<script src="<?php #echo base_url();?>js/morris.min.js"></script>-->
     <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
     <script src="<?php echo base_url();?>js/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery-jvectormap-world-mill-en.js"></script>
     <!--<script src="<?php #echo base_url();?>js/jquery.knob.js"></script>-->
     <!--<script src="<?php #echo base_url();?>js/Chart.min.js"></script><!-- AdminLTE App -->
     <script src="<?php echo base_url();?>js/moment.min.js"></script>
     <script src="<?php echo base_url();?>js/daterangepicker.js"></script>
     <script src="<?php echo base_url();?>js/bootstrap-datepicker.js"></script>
     <script src="<?php echo base_url();?>js/bootstrap3-wysihtml5.all.min.js"></script>
     <script src="<?php echo base_url();?>js/jquery.slimscroll.min.js"></script>  
    <script src="<?php echo base_url();?>js/fastclick.min.js"></script>
    <script src="<?php echo base_url();?>js/app.min.js"></script>
    <!--<script src="<?php #echo base_url();?>js/dashboard.js"></script>-->

     
      <!--******************************* Video modal **************************************************-->
<div class="modal fade" id="divVideoModal" tabindex="-1" role="dialog" aria-labelledby="modal-register-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button id="btnCloseModal" type="button" class="close" data-dismiss="modal" title="Click To Close The Popup Screen">
                    <span aria-hidden="true" style="font-size:xx-large;">&times;</span><span class="sr-only">Close</span>
                </button>
                
                <h3  id="idModalTitle"align="center" class=" makebold label-primary pad-3 modal-title" style="width:100%;"></h3>
            </div>
        
            <div class="register-box form-bottom modal-body" style="width:100%;">
              <div id="idModalBody" class="register-box-body"></div></div>
        
        </div><!--End modal-content-->
    </div><!--End modal-dialogue-->
</div>
<!--******************************* End Video modal **********************************************-->    
  </body>
</html>
