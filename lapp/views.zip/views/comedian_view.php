<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LaffHub::Comedians</title>
<link rel="icon" type="image/png" href="<?php echo base_url();?>images/icon.png">
<link href="<?php echo base_url();?>hcss/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>hcss/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">


<link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap-theme.min.css">


<link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/general.css">

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<link href="<?php echo base_url();?>css/ie10-viewport-bug-workaround.css" rel="stylesheet">

<!--Javascripts-->
<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"></script>

<script src="<?php echo base_url();?>js/holder.min.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src=<?php echo base_url();?>js/html5shiv.min.js"></script>
  <script src="<?php echo base_url();?>js/respond.min.js"></script>
<![endif]-->

<script src="<?php echo base_url();?>js/ie10-viewport-bug-workaround.js"></script>

<script src="<?php echo base_url();?>js/bootbox.min.js"></script>

<script>
	var Network='<?php echo $Network;?>';
	var Phone='<?php echo $Phone; ?>';
	var Email='<?php echo $subscriber_email; ?>';
</script>
</head>
<body>

<header> <?php include('usernav.php'); ?> </header>

<section class="channel-wrapper">
<div class="container">
<?php
	if (count($ComedianVideos)<2) $tit=$Comedian.'\'s Video'; else $tit=$Comedian.'\'s Videos';
		
	echo '
		<div class="row">
		  <h4 style="color:#B41012;"> '.$tit.' </h4>
		</div>	
	';
	
	if (count($ComedianVideos)>0)
	{		
		$i=0;
		
		foreach($ComedianVideos as $row):
			if (trim($row->video_code) and trim($row->thumbnail))
			{
				$row->video_title=trim(ucwords(strtolower($row->video_title)));
				$row->category=trim(ucwords(strtolower($row->category)));
				$videourl='c-'.$row->video_code;
				
				$i++; #i is row
				
				if ($i == 1) 
				{
					echo '
						<div class="channels">
							<div class="row">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								  <div class="channel-in"> 
								  	<a href="'.site_url($videourl).'"><img title="'.$row->video_title.'" src="https://s3-us-west-2.amazonaws.com/'.$thumbs_bucket.'/'.$row->category.'/'.trim($row->thumbnail).'" class="img-responsive"></a>
									
									<div class="list-div-text channel-in ">
									  <a href=""><h4 title="'.$row->video_title.'" style="height:40px; text-transform:capitalize; margin-top:-30px;"> '.$row->video_title.' </h4></a>
									  <h5 title="'.$row->category.'" style="text-transform:capitalize;margin-top:-40px;"> <span class="redtext">Category:</span> '.$row->category.' </h5>
									</div>
								  </div>
								</div>							
							';
								
				}else
				{
					echo '
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								  <div class="channel-in">
								  	<a href="'.site_url($videourl).'"><img title="'.$row->video_title.'" src="https://s3-us-west-2.amazonaws.com/'.$thumbs_bucket.'/'.$row->category.'/'.trim($row->thumbnail).'" class="img-responsive"></a>
									
									<div class="list-div-text channel-in ">
									  <a href=""><h4 title="'.$row->video_title.'" style="height:40px; text-transform:capitalize; margin-top:-30px;"> '.$row->video_title.' </h4></a>
									  <h5 title="'.$row->category.'" style="text-transform:capitalize;margin-top:-40px;"> <span class="redtext">Category:</span> '.$row->category.' </h5>
									</div>
								  </div>
								</div>
					';
				}
				
				if ($i == 4)
				{
					$i=0;
					
					echo '
							 </div>      
						</div>
					';
				}
			}
		endforeach;
	}else
	{
		echo '
			<div class="channels">
				<div class="row">
					<div class="channel-in"> 						
						<div class="list-div-text channel-in ">
						  <h4 style="font-size:16px;"> No Video </h4>
						</div>
					  </div>
				</div>	
			</div>							
				';
	}
?>
	

</section>


<?php include('userfooter.php'); ?>

<script src="<?php echo base_url();?>js/jquery.min.js"></script> 
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
</body>
</html>