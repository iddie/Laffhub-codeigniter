<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/bootstrap-theme.min.css">    
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/jquery.dataTables.css">
    
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/dataTables.jqueryui.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/select.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>css/buttons.dataTables.min.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/select.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.dataTables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/fixedHeader.jqueryui.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/select.jqueryui.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/ionicons.min.css">
    <!-- Theme style -->
   
    <link rel="stylesheet" href="<?php echo base_url();?>css/general.css">
    
    <link rel="stylesheet" href="<?php echo base_url();?>css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/datepicker3.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/red.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/morris.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/jquery-jvectormap-1.2.2.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap3-wysihtml5.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/fileinput.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap-multiselect.css">
    <link rel="stylesheet" href="<?php echo base_url();?>css/editor.css">
	
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"><\/script>')</script>  

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="<?php echo base_url();?>js/html5shiv.min.js"></script>
        <script src="<?php echo base_url();?>js/respond.min.js"></script>
    <![endif]-->
   
  
  
    <script type='text/javascript' src="<?php echo base_url();?>js/jquery.dataTables.min.js"></script>
	<script type='text/javascript' src="<?php echo base_url();?>js/dataTables.bootstrap.min.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/dataTables.select.min.js"></script> 
    <script type='text/javascript' src="<?php echo base_url();?>js/dataTables.fixedColumns.min.js"></script>
    
    <script type='text/javascript' src="<?php echo base_url();?>js/dataTables.buttons.min.js"></script>
	<script type='text/javascript' src="<?php echo base_url();?>js/buttons.bootstrap.min.js"></script>
     
    <script type='text/javascript' src="<?php echo base_url();?>js/buttons.colVis.min.js"></script>  
    <script type='text/javascript' src="<?php echo base_url();?>js/buttons.flash.min.js"></script>
     <script type='text/javascript' src="<?php echo base_url();?>js/jszip.min.js"></script>
     <script type='text/javascript' src="<?php echo base_url();?>js/pdfmake.min.js"></script>
     <script type='text/javascript' src="<?php echo base_url();?>js/vfs_fonts.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/buttons.html5.min.js"></script>
        <script type='text/javascript' src="<?php echo base_url();?>js/buttons.print.min.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/buttons.jqueryui.min.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/buttons.colVis.min.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/sum().js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/formatted-numbers.js"></script>
    <script type='text/javascript' src="<?php echo base_url();?>js/shCore.js"></script>
	<script type='text/javascript' src="<?php echo base_url();?>js/s8.min.js"></script>

   
    
    
    
    
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.blockUI.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/bootbox.min.js"></script>
    <script src="<?php echo base_url();?>js/plugins/canvas-to-blob.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>js/fileinput.min.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-multiselect.js"></script>
 	<script src="<?php echo base_url();?>js/editor.js"></script>
    <script src="<?php echo base_url();?>js/general.js"></script>
    <script src="<?php echo base_url();?>js/jquery.redirect.js"></script>
	<script src="<?php echo base_url();?>js/moment.min.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap-datetimepicker.min.js"></script>
   
    