
<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo base_url();?>css/AdminLTE.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/general.css">
<!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="<?php echo base_url();?>css/skins/_all-skins.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>iconfont/material-icons.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/datepicker3.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/daterangepicker-bs3.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/red.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/morris.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/jquery-jvectormap-1.2.2.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap3-wysihtml5.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/fileinput.css">

<!--Javascripts-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url();?>js/jquery-1.12.4_min.js"><\/script>')</script>

<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>js/holder.min.js"></script>
<script src="<?php echo base_url();?>js/app.min.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src=<?php echo base_url();?>js/html5shiv.min.js"></script>
  <script src="<?php echo base_url();?>js/respond.min.js"></script>
<![endif]-->

<script src="<?php echo base_url();?>js/ie10-viewport-bug-workaround.js"></script>
<script src="<?php echo base_url();?>js/jquery.blockUI.js"></script>    
<script src="<?php echo base_url();?>js/moment.min.js"></script>
<script src="<?php echo base_url();?>js/bootstrap-datetimepicker.min.js"></script>

<script src="<?php echo base_url();?>js/bootbox.min.js"></script>
<script src="<?php echo base_url();?>js/s8.min.js"></script>
<script src="<?php echo base_url();?>js/general.js"></script>

<script src="<?php echo base_url();?>js/plugins/canvas-to-blob.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/fileinput.min.js"></script>





