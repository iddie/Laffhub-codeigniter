<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Comedian extends CI_Controller {	
	
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->model('getdata_model');
	 }
	 
	 public function ShowComedian()
	 {
		 $id=''; $comedian='';
		
		if ($this->uri->segment(1)) $id=$this->uri->segment(3);
	
		
		$sql = "SELECT * FROM comedians WHERE (id=".$this->db->escape_str($id).")";
	
		$query = $this->db->query($sql);
					
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
		
			if ($row->comedian) $comedian=trim($row->comedian);
						
			#Get comedian videos
			$sql = "SELECT * FROM videos WHERE (TRIM(comedian)='".$this->db->escape_str($comedian)."')";
			
			$query = $this->db->query($sql);
#$file = fopen('aaa.txt',"w"); fwrite($file,$sql); fclose($file);				
			if ($query->num_rows() > 0 )
			{
				if ($_SESSION['subscriber_email']) $data['subscriber_email'] = $_SESSION['subscriber_email'];
		
				$data['Network']=$this->getdata_model->GetNetwork();
				$data['Phone']=$this->getdata_model->GetMSISDN();
					
				$_SESSION['Network']=$data['Network'];
				$_SESSION['Phone']=$data['Phone'];
				
				$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
				
				$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$data['Phone']);
								
				if (is_array($result))
				{
					$td=date('Y-m-d H:i:s');
					
					foreach($result as $row)
					{
						if ($row->subscribe_date) $dt = date('F d, Y',strtotime($row->subscribe_date));
						
						$data['subscribe_date'] = $dt;
						
						if ($row->exp_date) $edt = date('F d, Y',strtotime($row->exp_date));
						$data['exp_date'] = $edt;
						
						if ($td > date('Y-m-d H:i:s',strtotime($row->exp_date)))
						{
							if ($row->subscriptionstatus==1)
							{
								#Update Subscription Date
								$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'0');
							}
						}else
						{
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}
	
						break;
					}
				}
				
				$data['Categories']=$this->getdata_model->GetCategories();
				$data['Comedian']=urldecode($comedian);
				if ($_SESSION['thumbs_bucket']) $data['thumbs_bucket'] = $_SESSION['thumbs_bucket'];
				$data['ComedianVideos']=$this->getdata_model->GetComedianVideos($this->db->escape_str($comedian));
				$this->load->view('comedian_view',$data);
				
			}else
			{
				if ($_SESSION['subscriber_email']) $data['subscriber_email'] = $_SESSION['subscriber_email'];
				
				$data['Comedian']=urldecode($comedian);
				
				$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
				
				$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$data['Phone']);
								
				if (is_array($result))
				{
					$td=date('Y-m-d H:i:s');
					
					foreach($result as $row)
					{
						if ($row->subscribe_date) $dt = date('F d, Y',strtotime($row->subscribe_date));
						
						$data['subscribe_date'] = $dt;
						
						if ($row->exp_date) $edt = date('F d, Y',strtotime($row->exp_date));
						$data['exp_date'] = $edt;
						
						if ($td > date('Y-m-d H:i:s',strtotime($row->exp_date)))
						{
							if ($row->subscriptionstatus==1)
							{
								#Update Subscription Date
								$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'0');
							}
						}else
						{
							$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
						}
	
						break;
					}
				}
				
				$data['Network']=$this->getdata_model->GetNetwork();
				$data['Phone']=$this->getdata_model->GetMSISDN();
					
				$_SESSION['Network']=$data['Network'];
				$_SESSION['Phone']=$data['Phone'];
				
				$data['Categories']=$this->getdata_model->GetCategories();
				$data['Comedians']=$this->getdata_model->GetComedians();
				$this->load->view('comedian_view',$data);
			}
		}else
		{
			if ($_SESSION['subscriber_email']) $data['subscriber_email'] = $_SESSION['subscriber_email'];
			
			$data['Comedian']=urldecode($comedian);
			
			$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
			
			$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$data['Phone']);
								
			if (is_array($result))
			{
				$td=date('Y-m-d H:i:s');
				
				foreach($result as $row)
				{
					if ($row->subscribe_date) $dt = date('F d, Y',strtotime($row->subscribe_date));
					
					$data['subscribe_date'] = $dt;
					
					if ($row->exp_date) $edt = date('F d, Y',strtotime($row->exp_date));
					$data['exp_date'] = $edt;
					
					if ($td > date('Y-m-d H:i:s',strtotime($row->exp_date)))
					{
						if ($row->subscriptionstatus==1)
						{
							#Update Subscription Date
							$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$data['Phone'],'0');
						}
					}else
					{
						$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
					}

					break;
				}
			}
			
			$data['Network']=$this->getdata_model->GetNetwork();
			$data['Phone']=$this->getdata_model->GetMSISDN();
				
			$_SESSION['Network']=$data['Network'];
			$_SESSION['Phone']=$data['Phone'];
			
			$data['Categories']=$this->getdata_model->GetCategories();
			$data['Comedians']=$this->getdata_model->GetComedians();
			$this->load->view('comedian_view',$data);
		}
	 }
		
	public function index()
	{
		if ($_SESSION['thumbs_bucket']) $data['thumbs_bucket'] = $_SESSION['thumbs_bucket'];
		if ($_SESSION['subscriber_email']) $data['subscriber_email'] = $_SESSION['subscriber_email'];
		
		$data['Network']=$this->getdata_model->GetNetwork();
		$data['Phone']=$this->getdata_model->GetMSISDN();
			
		$_SESSION['Network']=$data['Network'];
		$_SESSION['Phone']=$data['Phone'];
			
		$data['Categories']=$this->getdata_model->GetCategories();
		$this->load->view('comedian_view',$data);#Fail Page	
	}
}
