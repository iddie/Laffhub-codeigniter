<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Africa/Lagos');

class V extends CI_Controller {	
	
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->model('getdata_model');
		
	 }

	public function AddComment()
	{		#category, filename, videocode, name, comment
		$email=''; $category=''; $filename=''; $videocode=''; $name=''; $comment=''; $videotitle='';
		$phone='';
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = trim($this->input->post('email'));
		if ($this->input->post('category')) $category = trim($this->input->post('category'));
		if ($this->input->post('filename')) $filename = trim($this->input->post('filename'));
		if ($this->input->post('videotitle')) $videotitle = trim($this->input->post('videotitle'));
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('name')) $name = $this->input->post('name');
		if ($this->input->post('comment')) $comment = $this->input->post('comment');		
#$file = fopen('aaa.txt',"w"); fwrite($file,$action); fclose($file);
				
		//Check if record exists
		$sql = "SELECT * FROM comments WHERE ((TRIM(phone)='".$this->db->escape_str($phone)."') OR (TRIM(email)='".$this->db->escape_str($email)."')) AND (TRIM(videocode)='".$this->db->escape_str($videocode)."') AND (TRIM(comment)='".$this->db->escape_str($comment)."')";
		$query = $this->db->query($sql);
					
		if ($query->num_rows() > 0 )
		{
			$ret = 'Comment <b>'.strtoupper($comment).'</b> for the video <b>'.strtoupper($videotitle).'</b> has already been added.';
		}else
		{
			$dt=date('Y-m-d H:i:s');
			
			$this->db->trans_start();
									
			$dat=array(
				'email' => $this->db->escape_str($email),
				'phone' => $this->db->escape_str($phone),
				'category' => $this->db->escape_str($category),
				'filename' => $this->db->escape_str($filename),
				'videotitle' => $this->db->escape_str($videotitle),
				'videocode' => $this->db->escape_str($videocode),
				'name' => $this->db->escape_str($name),
				'comment' => $this->db->escape_str($comment),				
				'commentstatus' => 1,
				'commentdate' => $dt
				);							
			
			$this->db->insert('comments', $dat);
			
			$this->db->trans_complete();
			
			$Msg='';
			
			if ($this->db->trans_status() === FALSE)
			{
				if ($phone)
				{
					$Msg="Subscriber ".strtoupper($name.'('.$phone.')')." attempted adding comment but failed.";
				}elseif ($email)
				{
					$Msg="Subscriber ".strtoupper($name.'('.$email.')')." attempted adding comment but failed.";
				}
								
				$ret = 'Comment Addition Was Not Successful.';
			}else
			{
				if ($phone)
				{
					$Msg="Comment By Subscriber ".strtoupper($name.'('.$phone.')')." Was Added Successfully.";
				}elseif ($email)
				{
					$Msg="Comment By Subscriber ".strtoupper($name.'('.$email.')')." Was Added Successfully.";
				}				
								
				$ret = 'OK'	;
			}
			
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
			$this->getdata_model->LogDetails($name,$Msg,$email,date('Y-m-d H:i:s'),$remote_ip,$remote_host,'ADDED COMMENT',$_SESSION['LogID']);
		}
		
		echo $ret;
	}
	
	public function PlayVideo1()
	{
		$videocode=''; $subscriptionId=''; $MaxVideo=''; $VideoTitle=''; $thumbnail=''; 
		$VideosWatched=0; $SubscriberEmail=''; $DurationInSeconds='0'; $Plan=''; $CurrentVideoCount=0;
		$SubscriberName=''; $phone=''; $network=''; $CommentsCount='0'; $videolist=''; $CanPlayVideo=false;
		$NoPlayReason=''; $CanPlayNew=false; $lang=''; $useragent='';
		
		$phone=$this->getdata_model->GetMSISDN();
		$network=$this->getdata_model->GetNetwork();
		
		$data['Phone']=$phone;
		$data['Network']=$network;
		$ret=$network;
				
		#Check network
		if ((strtolower(trim($ret))<> 'airtel') and (strtolower(trim($ret))<>'mtn'))
		{			
			if ($this->uri->segment(1)) $videocode=trim(str_replace('c-','',$this->uri->segment(1)));
	
			$tdt=date("Y-m-d H:i:s");
			
			$data['filename']=''; $data['title']=''; $data['jwplayer_key']='';
			$data['description']=''; $data['category']=''; $data['domain_name']='';
			$data['distribution_Id']=''; $data['origin'] = '';
			$data['subscriptionstatus'] = '<span style="color:#9E0911;">Not Active</span>';
			$data['SubscribeStatus'] = '0';
			
			$useragent=$_SERVER['HTTP_USER_AGENT'];
			$lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];	

			#Get Player Key
			$sql="SELECT * FROM settings";
				
			$query = $this->db->query($sql);
					
			if ( $query->num_rows()> 0 )
			{
				$row = $query->row();	
		
				if ($row->jwplayer_key)
				{
					$data['jwplayer_key'] = $row->jwplayer_key;
					$_SESSION['jwplayer_key']=$row->jwplayer_key;
				}
				
				if ($row->thumbs_bucket)
				{
					$ThumbBucket = $row->thumbs_bucket;
					$_SESSION['thumbs_bucket']=$ThumbBucket;
				}
			}
			
			#Get domain_name
			$sql="SELECT domain_name,distribution_Id,origin FROM streaming_domain";
				
			$query = $this->db->query($sql);
					
			if ( $query->num_rows()> 0 )
			{
				$row = $query->row();						
				if ($row->domain_name)
				{
					$data['domain_name'] = trim($row->domain_name);
					$_SESSION['domain_name']=$data['domain_name'];
				}
				
				if ($row->distribution_Id)
				{
					$data['distribution_Id']=trim($row->distribution_Id);
				}
				
				if ($row->domain_name)
				{
					
				}
			}
			
			
			
			#Get domain_name
			if ($_SESSION['distribution_Id']) $data['distribution_Id']=$_SESSION['distribution_Id'];
			
			if ($_SESSION['origin']) $data['origin'] = $_SESSION['origin'];
			
			#Check if subscriber has record in subscription table
			#subscriptionId,videos_cnt_to_watch,subscriptionstatus
			$sql = "SELECT * FROM subscriptions WHERE (TRIM(msisdn)='".$this->db->escape_str($phone)."') ";
			
			$query = $this->db->query($sql);
					
			if ($query->num_rows() > 0 )
			{
				$row = $query->row();
				
				if ($row->subscriptionId) $subscriptionId=trim($row->subscriptionId);
				if ($row->videos_cnt_to_watch) $MaxVideo=trim($row->videos_cnt_to_watch);
				if ($row->subscriptionstatus) $subscription_status=$row->subscriptionstatus;
				if ($row->plan) $Plan=trim($row->plan);
				if ($row->email) $SubscriberEmail=trim($row->email);
				
				if (strtolower($MaxVideo)=='unlimited') $MaxVideo='1000000000';
				
				$data['subscriber_email']= $SubscriberEmail;
				$data['MaxVideo']=$MaxVideo;
				$data['subscriptionId'] = $subscriptionId;
				
				if (!$subscription_status) $subscription_status='0';
				
				#Check if Subscription is active
				$result=$this->getdata_model->GetSubscriptionDate($data['subscriber_email'],$phone);
								
				if (is_array($result))
				{
					foreach($result as $rw)
					{
						if ($rw->subscribe_date) $dt = date('F d, Y',strtotime($rw->subscribe_date));
						
						$data['subscribe_date'] = $dt;
						
						if ($rw->exp_date) $edt = date('F d, Y',strtotime($rw->exp_date));
						$data['exp_date'] = $edt;
						
						if ($tdt > date('Y-m-d H:i:s',strtotime($rw->exp_date)))
						{
							if ($rw->subscriptionstatus==1)
							{
								#Update Subscription Date
								$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$phone,'0');
								$data['SubscribeStatus'] = '0';
							}
						}else
						{
							if (!$rw->subscriptionstatus)
							{
								$this->getdata_model->UpdateSubscriptionStatus($data['subscriber_email'],$phone,'1');
								$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
								$data['SubscribeStatus'] = '1';
							}else
							{
								$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
								$data['SubscribeStatus'] = '1';
							}
						}
	
						break;
					}
				}	

				if (intval($data['SubscribeStatus'],10) == 1)
				{
					#Get Video Lists
					$sql = "SELECT videolist FROM watchlists WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
		
					$query = $this->db->query($sql);
					
					#Get VideosWatched
					if ($query->num_rows() > 0 )
					{
						$row = $query->row();
					
						if ($row->videolist) $videolist=trim($row->videolist);
						
						if ($videolist <> '') $VideosWatched=count(explode('^',$videolist)); else $VideosWatched=0;
					}else
					{
						$VideosWatched=0;
					}
					
					$data['VideosWatched']=$VideosWatched;
					
					#Get Current Video Count
					if ($videolist <> '')
					{
						$arrWatched=array(); 
				
						$arrTotalWatched=explode('^',$videolist);
						
						if (count($arrTotalWatched)>0)
						{
							foreach($arrTotalWatched as $itm):
								if ($itm)
								{
									$ex=explode('|',$itm);
									
									if (count($ex)>0)
									{
										if (trim($ex[0])== trim($videocode)) $CurrentVideoCount=$ex[1];
									}
								}
							endforeach;
						}
					}
					
					$data['CurrentVideoCount']=$CurrentVideoCount;
					
					#Get Video Duration & Total Comments
					$sql = "SELECT * FROM videos WHERE (play_status=1) AND (encoded=1) AND (TRIM(video_code)='".$this->db->escape_str($videocode)."')";
		
					$query = $this->db->query($sql);
								
					if ($query->num_rows() > 0 )
					{
						$row = $query->row();
					
						if ($row->filename) $data['filename']=$row->filename;
						if ($row->video_title) $data['title']=$row->video_title;
						if ($row->description) $data['description']=$row->description;
						if ($row->category) $data['category']=$row->category;
						if ($row->thumbnail) $data['thumbnail']=$row->thumbnail;

						if ($row->duration)
						{
							$data['duration']=$row->duration;				
							$d=explode(':',$row->duration);
							
							$sec=0;
							
							if (count($d)==3)
							{
								$sec=(intval($d[0],10)*120)+(intval($d[1],10)*60)+intval($d[2],10);
							}elseif (count($d)==2)
							{
								$sec=(intval($d[0],10)*60)+intval($d[1],10);
							}
							
							$data['duration_secs']=$sec;
						}
						
						#Comments 
						$data['Comments']=$this->getdata_model->GetVideoComments($data['category'],$videocode,$data['filename']);
						if (count($data['Comments'])>1)
						{
							$data['CommentsCount']=count($data['Comments']).' Comments';
						}else
						{
							$data['CommentsCount']=count($data['Comments']).' Comment';
						}
					}
					
					###PUTTING ALL TOGETHER
					#Check if current video maximum count of 3 has been reached
					if ($CurrentVideoCount >= 3)
					{
						if (intval($VideosWatched,10) >= intval($MaxVideo,10))
						{
							#Stop. Exhausted all videos
							$CanPlayVideo=false;
							$NoPlayReason='You Have Exhausted All The Videos You Are Allowed To Watch For The Current Subscription Plan. Please Renew Your Subscription.';
							$CanPlayNew=false;
						}else
						{
							#Stop but can choose another video
							$CanPlayVideo=false;
							$NoPlayReason='You Have Reached The Maximum Number Of Times The Current Video. You Can, However, Watch A New Video.';
							$CanPlayNew=true;
						}
					}else
					{
						#Play
						$CanPlayVideo=true;
						$CanPlayNew=true;
						$NoPlayReason='';
					}
					
					$data['CanPlayVideo']=$CanPlayVideo;
					$data['CanPlayNew']=$CanPlayNew;
					$data['NoPlayReason']=$NoPlayReason;
					
					#Save Transaction
					$remote_ip=$_SERVER['REMOTE_ADDR'];
					$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
					
					#$tddate=date('Y-m-d H:i',strtotime($tdt));
					$tddate=date('Y-m-d',strtotime($tdt));
					
					#Check if it is first time it registering
					#$sql = "SELECT trans_date FROM transactions WHERE (DATE_FORMAT(trans_date,'%Y-%m-%d')='".$tddate."') AND (TRIM(video_code)='".$videocode."') AND (TRIM(phone)='".$phone."')";
				
					#$qry = $this->db->query($sql);
					
					$this->db->trans_start();
								
					$dat=array(
						'email' => $this->db->escape_str($data['subscriber_email']),
						'phone' => $this->db->escape_str($phone),
						'trans_date' => $tdt,
						'filename' => $this->db->escape_str($data['filename']),
						'video_code' => $this->db->escape_str($videocode),
						'user_agent' => $this->db->escape_str($useragent),
						'video_category' => $this->db->escape_str($data['category']),
						'remote_address' => $this->db->escape_str($remote_ip),	
						'remote_host' => $this->db->escape_str($remote_host),	
						'lang' => $this->db->escape_str($lang),
						'network' => $network
					);
					
					$this->db->insert('transactions', $dat);	
						
					$this->db->trans_complete();
					
					if ($this->db->trans_status() === FALSE)
					{
						$Msg="Transaction From Subscriber With Phone Number'".strtoupper($phone)." Failed.";	
						
						$this->getdata_model->LogDetails($phone,$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW WATCH VIDEO REQUEST','System');
					}else
					{
						$Msg="Transaction From Subscriber With Phone Number'".strtoupper($phone)." Was Successful.";	
						
						$this->getdata_model->LogDetails($phone,$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW WATCH VIDEO REQUEST','System');
					}
					
					$arr = explode('.', basename($data['filename']));
					$ext=array_pop($arr);				
					$fn=str_replace('.'.$ext,'',basename($data['filename']));
					
					$preview_img='https://s3-us-west-2.amazonaws.com/'.$ThumbBucket.'/'.$data['category'].'/'.$data['thumbnail'];
					$data['videocode'] = $videocode;
					$data['thumbs_bucket'] = $ThumbBucket;
					$data['preview_img']=$preview_img;
					$data['RelatedVideos']=$this->getdata_model->GetRelatedVideos($data['category'],$videocode);					
					$data['ViewPagePopularVideos']=$this->getdata_model->GetViewPagePopularVideos($videocode);
					$data['Categories']=$this->getdata_model->GetCategories();

#$file = fopen('aaa.txt',"w"); fwrite($file,"Phone=".$phone."\nMaxVideo=".$MaxVideo."\nSubscribeStatus=".$data['SubscribeStatus']."\nVideo Code=".$videocode."\nCurrentVideoCount=".$CurrentVideoCount."\nVideosWatched=".$VideosWatched."\nCanPlayVideo=".$data['CanPlayVideo']."\nCanPlayNew=".$data['CanPlayNew']."\nNoPlayReason=".$data['NoPlayReason']."\nSubcriber Id=".$data['subscriptionId']."\nCategory=".$data['category']); fclose($file);
					
					$this->load->view('v_view',$data);
				}else
				{
					$this->load->view('expiredsubscription',$data);
				}
			}else
			{
				$this->load->view('nosubscription',$data);
			}
		}elseif (strtolower(trim($ret))=='mtn')
		{
			if ($host=='localhost')
			{
				redirect('http://localhost/laffhub/Home', 'refresh');
				#redirect('http://localhost/mtnlaffhub/Subscriberhome', 'refresh');
			}else
			{
				redirect('https://laffhub.com/Home', 'refresh');
				#redirect('https://mtn.laffhub.com/Subscriberhome', 'refresh');
			}
		}elseif (strtolower(trim($ret))=='airtel')
		{
			if ($host=='localhost')
			{
				redirect('http://localhost/airtellaffhub/Subscriberhome', 'refresh');
			}else
			{
				redirect('http://airtel.laffhub.com/Subscriberhome', 'refresh');
			}				
		}
	}
	
	public function PlayVideo()
	{
		$videocode=''; $subscriptionId=''; $videos_cnt_to_watch=''; $VideoTitle=''; $thumbnail='';
		$VideosWatched=0; $subscription_status='';
		
		if ($this->uri->segment(1)) $videocode=trim(str_replace('c-','',$this->uri->segment(1)));
				
		$tdt=date("Y-m-d H:i:s");
		
		$data['filename']=''; $data['title']=''; $data['jwplayer_key']='';
		$data['description']=''; $data['category']=''; $data['domain_name']='';
		$useragent=$_SERVER['HTTP_USER_AGENT'];
		$lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
		$phone=$this->getdata_model->GetMSISDN();
		$network=$this->getdata_model->GetNetwork();
		
		#Get Player Key
		$sql="SELECT * FROM settings";
			
		$query = $this->db->query($sql);
				
		if ( $query->num_rows()> 0 )
		{
			$row = $query->row();	

			if ($row->jwplayer_key) $data['jwplayer_key'] = $row->jwplayer_key;
			if ($row->thumbs_bucket) $ThumbBucket = $row->thumbs_bucket;
		}
		
		#Get domain_name
		$sql="SELECT domain_name FROM streaming_domain";
			
		$query = $this->db->query($sql);
				
		if ( $query->num_rows()> 0 )
		{
			$row = $query->row();						
			if ($row->domain_name) $data['domain_name'] = $row->domain_name;
		}
		
		#Get Video record
		$sql = "SELECT * FROM videos WHERE (play_status=1) AND (encoded=1) AND (TRIM(video_code)='".$this->db->escape_str($videocode)."')";
		
		$query = $this->db->query($sql);
					
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
		
			if ($row->filename) $data['filename']=$row->filename;
			if ($row->video_title) $data['title']=$row->video_title;
			if ($row->description) $data['description']=$row->description;
			if ($row->category) $data['category']=$row->category;
			if ($row->thumbnail) $data['thumbnail']=$row->thumbnail;
						
			if ($row->duration)
			{
				$data['duration']=$row->duration;				
				$d=explode(':',$row->duration);
				
				$sec=0;
				
				if (count($d)==3)
				{
					$sec=(intval($d[0],10)*120)+(intval($d[1],10)*60)+intval($d[2],10);
				}elseif (count($d)==2)
				{
					$sec=(intval($d[0],10)*60)+intval($d[1],10);
				}
				
				$data['duration_secs']=$sec;
			}
			
			#Save Transaction
			$remote_ip=$_SERVER['REMOTE_ADDR'];
			$remote_host=gethostbyaddr($_SERVER['REMOTE_ADDR']);
			
			$data['Phone']=$phone;
			$data['Network']=$network;
			$data['subscriber_email']=$_SESSION['subscriber_email'];	
			$data['subscriber_name'] = $_SESSION['subscriber_name'];
			$data['subscriptionstatus'] = '<span style="color:#099E11;">Active</span>';
			
			#Get active subscription ID
			$sql = "SELECT subscriptionId,videos_cnt_to_watch,subscriptionstatus FROM subscriptions WHERE ((TRIM(msisdn)='".$this->db->escape_str($phone)."') OR (TRIM(email)='".$this->db->escape_str($data['subscriber_email'])."')) ";
			
			$subscriptionId='';
			$videos_cnt_to_watch='Unlimited';
			$subscription_status=1;
			
			#$tddate=date('Y-m-d H:i',strtotime($tdt));
			$tddate=date('Y-m-d',strtotime($tdt));
			
			#Check if it is first time it registering
			$sql = "SELECT trans_date FROM transactions WHERE (DATE_FORMAT(trans_date,'%Y-%m-%d')='".$tddate."') AND (TRIM(filename)='".$row->filename."') AND ((TRIM(remote_address)='".$_SERVER['REMOTE_ADDR']."') OR (TRIM(email)='admin@laffhub.com'))";
		
			$qry = $this->db->query($sql);
						
			$dat=array(
				'email' => $this->db->escape_str($data['subscriber_email']),
				'phone' => $this->db->escape_str($phone),
				'trans_date' => $tdt,
				'filename' => $this->db->escape_str($row->filename),
				'video_code' => $this->db->escape_str($videocode),
				'user_agent' => $this->db->escape_str($useragent),
				'video_category' => $this->db->escape_str($row->category),
				'remote_address' => $this->db->escape_str($remote_ip),	
				'remote_host' => $this->db->escape_str($remote_host),	
				'lang' => $this->db->escape_str($lang),
				'network' => $network
			);
			
			$this->db->insert('transactions', $dat);	
				
			$this->db->trans_complete();
			
			if ($this->db->trans_status() === FALSE)
			{
				$Msg="Transaction From User Agent '".strtoupper($useragent).", Remote Host '".strtoupper($remote_host)."' AND Remote IP'".strtoupper($remote_ip)."' Failed.";	
				
				$this->getdata_model->LogDetails('System',$Msg,'System',date('Y-m-d H:i:s'),$remote_ip,$remote_host,'NEW VIDEO REQUEST','System');
			}	
			
			$arr = explode('.', basename($row->filename));
			$ext=array_pop($arr);				
			$fn=str_replace('.'.$ext,'',basename($row->filename));
			
			$preview_img='https://s3-us-west-2.amazonaws.com/'.$ThumbBucket.'/'.$data['category'].'/'.$data['thumbnail'];
			
			$data['videocode'] = $videocode;
			$data['VideosToWatch'] = $videos_cnt_to_watch;
			$data['subscriber_phone'] = $phone;
			$data['video_category'] = $row->category;			
			$data['thumbs_bucket'] = $ThumbBucket;
			$data['subscriptionId'] = $subscriptionId;			
			$data['subscriber_status'] = 1;			
			$data['subscription_status']=$subscription_status;
			$data['preview_img']=$preview_img;
			$data['RelatedVideos']=$this->getdata_model->GetRelatedVideos($row->category,$videocode);
			#$data['Comments']=$this->getdata_model->GetVideoComments($row->category,$videocode,$row->filename);
			$data['ViewPagePopularVideos']=$this->getdata_model->GetViewPagePopularVideos($videocode);
			
			#if (count($data['Comments'])>1)
			#{
			#	$data['CommentsCount']=count($data['Comments']).' Comments';
			#}else
		#	{
			#	$data['CommentsCount']=count($data['Comments']).' Comment';
			#}
			
			$data['Categories']=$this->getdata_model->GetCategories();
			
			$this->load->view('v_view',$data);
		}else
		{
			$this->load->view('notfound',$data);
		}
	}
	
	public function CheckForWatchCount()
	{
		$phone=''; $email=''; $videocode=''; $subscriptionId=''; $videos_cnt_to_watch='';
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = $this->input->post('email');
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('subscriptionId')) $subscriptionId = trim($this->input->post('subscriptionId'));
		
		#Get videos_cnt_to_watch
		$sql = "SELECT videos_cnt_to_watch FROM subscriptions WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
			
		$query = $this->db->query($sql);
				
		if ($query->num_rows() > 0 )
		{
			$row = $query->row();
			
			if ($row->videos_cnt_to_watch) $videos_cnt_to_watch=$row->videos_cnt_to_watch;
		}
		
		$sql = "SELECT videolist FROM watchlists WHERE (TRIM(subscriptionId)='".$this->db->escape_str($subscriptionId)."')";
		
			$query = $this->db->query($sql);
			
			$videolist='';
			
			if ($query->num_rows() > 0 )
			{
				$row = $query->row();
			
				if ($row->videolist) $videolist=trim($row->videolist);
			}
			
		
			#Check total number of videos watched - VideoCode|WatchCount^VideoCode|WatchCount
			if ($videolist <> '')
			{
				$arrWatched=array(); $tempTotal=0; $tempLimit=0; $codeexists=false;
				
				$arrTotalWatched=explode('^',$videolist);
				
				$VideosWatched=count($arrTotalWatched);
					
				if (count($arrTotalWatched)>0)
				{
					$tempTotal=count($arrTotalWatched);
					
					foreach($arrTotalWatched as $itm):
						if ($itm)
						{
							$ex=explode('|',$itm);
							
							if (count($ex)>0)
							{
								$arrWatched[$ex[0]]=$ex[1]; #array[videocode]=watchcount
							}
						}
					endforeach;
				}
				
				if (count($arrWatched)>0)
				{					
					foreach($arrWatched as $code => $cnt):
						if ($code)
						{
							if (trim($code) == trim($videocode))
							{
								$codeexists=true;
								$tempLimit=intval($cnt,10);

								break;
							}
						}
					endforeach;
					
					#Code exists, check watch count
					if ($codeexists==true)
					{
						if ($tempLimit < 3)#OK
						{
							$data='OK';
						}else#Exceed video limit
						{
							if (strtolower(trim($videos_cnt_to_watch)) <> 'unlimited')
							{
								if (intval($tempTotal,10) < intval($videos_cnt_to_watch,10))#OK
								{
									$diff=intval($videos_cnt_to_watch,10) - intval($tempTotal,10);
									
									if ($diff<2)
									{
										$data='You have watched this particular video 3 times. However, you still have the privilege of selecting <b>' . $diff . ' new video</b> for your current subscription plan.';
									}else
									{
										$data='You have watched this particular video 3 times. However, you still have the privilege of selecting <b>' . $diff . ' new videos</b> for your current subscription plan.';
									}
								}else
								{
									$data='You have exceeded the total number of videos allowed for your current subscription plan. Please renew your subscription to watch videos.';
								}		
							}else
							{
								$data='You have watched this particular video 3 times. You still have the privilege of selecting <b>UNLIMITED new videos</b> for your current subscription plan.';
							}
						}
					}else #Code not exist, check total videos
					{
						if (strtolower(trim($videos_cnt_to_watch)) <> 'unlimited')
						{
							if (intval($tempTotal,10) < intval($videos_cnt_to_watch,10))
							{
								$data='OK';
							}else
							{
								$data='You have exceeded the total number of videos allowed for your current subscription plan. Please renew your subscription to watch videos.';
							}	
						}else
						{
							$data='You have watched this particular video 3 times. You still have the privilege of selecting <b>UNLIMITED new videos</b> for your current subscription plan.';
						}						
					}
				}else
				{
					$data='OK';	
				}
			}else
			{
				$data='OK';
			}
		
		echo $data;
	}
	
	public function UpdateWatchCount()
	{
		$phone=''; $email=''; $videocode=''; $subscriptionId='';
		
		if ($this->input->post('phone')) $phone = trim($this->input->post('phone'));
		if ($this->input->post('email')) $email = $this->input->post('email');
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
		if ($this->input->post('subscriptionId')) $subscriptionId = trim($this->input->post('subscriptionId'));
		
		$this->getdata_model->SetWatchCount($videocode,$phone,$email,$subscriptionId);	
		
		echo 'OK';				
	}
	
	public function UpdateWatchCountSpecial()
	{
		$videocode='';
		
		if ($this->input->post('videocode')) $videocode = trim($this->input->post('videocode'));
				
		$sql="SELECT watchcount FROM videos WHERE (TRIM(video_code)='".$this->db->escape_str($videocode)."')";	
		$query = $this->db->query($sql);	

		$wc=0;
				
		if ($query->num_rows() > 0 )#Update
		{
			$row=$query->row();
			
			if ($row->watchcount) $wc=$row->watchcount;
		}
		
		$wc++;
		
		$this->db->trans_start();
		
		$dat=array('watchcount' => $wc);
				
		$this->db->where('video_code',$videocode);
		$this->db->update('videos', $dat);
		
		$this->db->trans_complete();	
		
		echo 'OK';				
	}
	
#https://d2dm1rzdyku85l.cloudfront.net/Alzheimers_Risk_360p.mp4
#if ($domainname && $filename) $preview_url='https://'.$domainname.'/'.$filename;	
	public function index()
	{
				
	}
}
